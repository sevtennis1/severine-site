##############################################################################
############################################################################## 
#############  Analysis - Main analysis, figures, tables, and some appendix tables ####
############################################################################## 
############################################################################## 

##### CHANGE THIS PATH #####
raw_path <- "YOUR PATH HERE"


#######################################
########## Setup ########## 
####################################### 
#### Load Libraries
library(rio)
library(tidyverse)
library(ggplot2)
library(plyr)
library(dplyr)
library(grid)
library(ggcorrplot)
library(jtools)
library(psych)
library(poLCA)
library(reshape2)
library(stringr)
library(ggtext)
library(tm)
library(wordcloud)
library(SnowballC)


### Set other paths 
path <- paste0(raw_path,"/Replication Package/")
inpath <- paste0(path,"/Cleaned Data/") 
inpath_comments <- paste0(path,"/Data about comments/")
outpath <- paste0(path,"/Figures/") 

### Helper functions
wrapper <- function(x, ...) 
{
  paste(strwrap(x, ...), collapse = "\n")
}

#######################################
########## Data Cleaning ########## 
#######################################

##### Main Data #####

### Load Main Data
all_survey_results <- import(paste(inpath,"all_survey_data.xlsx", sep=""))
all_survey_results$ID <- rownames(all_survey_results)


all_survey_results_2 <- all_survey_results


### Create Binned Location variable
all_survey_results$loc_bin[all_survey_results$location == "Afghanistan"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Argentina"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Australia"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Austria"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Bahrain"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Belgium"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Brazil"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Canada"] <- "United States/Canada"
all_survey_results$loc_bin[all_survey_results$location == "Chile"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "China"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Colombia"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Czech Republic"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Denmark"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Finland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "France"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Germany"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Greece"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Guatemala"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Hong Kong (S.A.R.)"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Hungary"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "India"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Iran, Islamic Republic of..."] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Ireland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Israel"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Italy"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Japan"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Liechtenstein"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Luxembourg"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Mexico"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Netherlands"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "New Zealand"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Norway"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Philippines"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Poland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Portugal"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Prefer not to say"] <- "Prefer not to say"
all_survey_results$loc_bin[all_survey_results$location == "Republic of Korea"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Russian Federation"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Saint Vincent and the Grenadines"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Serbia"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Singapore"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Slovakia"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "South Korea"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Spain"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Sweden"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Switzerland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Thailand"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Turkey"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "United Arab Emirates"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "United Kingdom of Great Britain and Northern Ireland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "United States of America"] <- "United States/Canada"
all_survey_results$loc_bin[all_survey_results$location == "Uruguay"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Uzbekistan"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Zimbabwe"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Prefer not to say"] <- "Prefer not to say"

all_survey_results$loc_bin[all_survey_results$loc_bin == "Other"] <- "Other countries"

### Create Binned Age variable
all_survey_results$age_reduced <- all_survey_results$age
all_survey_results$age_reduced[all_survey_results$age_reduced=="Under 30"] <- "Under 40"
all_survey_results$age_reduced[all_survey_results$age_reduced=="30-39"] <- "Under 40"
all_survey_results$age_reduced[all_survey_results$age_reduced=="60-69"] <- "60+"
all_survey_results$age_reduced[all_survey_results$age_reduced=="70+"] <- "60+"

### Create Binned Position variable
all_survey_results$pos_reduced <- all_survey_results$position
all_survey_results$pos_reduced[all_survey_results$pos_reduced=="PhD candidate"] <- "Postdoc/PhD"
all_survey_results$pos_reduced[all_survey_results$pos_reduced=="Post-doctoral researcher"] <- "Postdoc/PhD"

### Create Reports to Non-Econ and Econ Journals
all_survey_results$ref_repor_per_year <- as.numeric(all_survey_results$ref_repor_per_year)
all_survey_results$non_econ_rep_perc <- as.numeric(all_survey_results$perc_ref_rep_journals_4_other_discipline)
all_survey_results$non_econ_rep_perc <- all_survey_results$non_econ_rep_perc/100
all_survey_results$econ_rep_perc <- 1-all_survey_results$non_econ_rep_perc
all_survey_results$econ_reps <- all_survey_results$econ_rep_perc*all_survey_results$ref_repor_per_year

### Create total referee requests
all_survey_results$req_rej_num <- 0
all_survey_results$req_rej_num[!is.na(all_survey_results$rej_ref_req_num_times_with_0)] <- all_survey_results$rej_ref_req_num_times_with_0[!is.na(all_survey_results$rej_ref_req_num_times_with_0)]
all_survey_results$req_rej_num[!is.na(all_survey_results$rej_ref_req_num_times)] <- all_survey_results$rej_ref_req_num_times[!is.na(all_survey_results$rej_ref_req_num_times)]
all_survey_results$req_rej_num <- as.numeric(all_survey_results$req_rej_num)
all_survey_results$ref_repor_per_year <- as.numeric(all_survey_results$ref_repor_per_year)
all_survey_results$ref_req_tot <- NA
all_survey_results$ref_req_tot[!is.na(all_survey_results$req_rej_num)] <-  all_survey_results$req_rej_num[!is.na(all_survey_results$req_rej_num)]/2+all_survey_results$ref_repor_per_year[!is.na(all_survey_results$req_rej_num)]

### Create rejection rate
all_survey_results$reject_rate[!is.na(all_survey_results$ref_req_tot)] <- (all_survey_results$req_rej_num[!is.na(all_survey_results$ref_req_tot)]/(2*all_survey_results$ref_req_tot[!is.na(all_survey_results$ref_req_tot)]))*100

### Create referee request quartiles
all_survey_results$ref_req_tot_quart[!is.na(all_survey_results$ref_req_tot)] <- "Q1"
all_survey_results$ref_req_tot_quart[all_survey_results$ref_req_tot > 5.5] <- "Q2"
all_survey_results$ref_req_tot_quart[all_survey_results$ref_req_tot > 10] <- "Q3"
all_survey_results$ref_req_tot_quart[all_survey_results$ref_req_tot > 15.75] <- "Q4"

### Create referee reports quartiles
all_survey_results$ref_repor_quart[!is.na(all_survey_results$ref_repor_per_year)] <- "Q1"
all_survey_results$ref_repor_quart[all_survey_results$ref_repor_per_year > 4] <- "Q2"
all_survey_results$ref_repor_quart[all_survey_results$ref_repor_per_year > 8] <- "Q3"
all_survey_results$ref_repor_quart[all_survey_results$ref_repor_per_year > 12] <- "Q4"

## Make Number of Submissions numeric
all_survey_results$num_pap_sub <- as.numeric(all_survey_results$num_pap_sub)


##### Other Dataframes #####
### Fields Dataframe
fields2 <- as.data.frame(all_survey_results$research_areas)
colnames(fields2) <- "field"
fields2 <- as.data.frame(str_split_fixed(fields2$field, ",",n=13))
fields2$ID <- rownames(fields2)
fields_for_all <- fields2




### Demographics Subset Dataframe with binary variables
new_het_fig <- all_survey_results
new_het_fig$pos <- all_survey_results$pos_reduced
new_het_fig$gender <- all_survey_results$gender
new_het_fig$edit <- all_survey_results$have_been_editor
new_het_fig$top_5 <- all_survey_results$perc_ref_rep_journals_1_top_5
new_het_fig$reps <- all_survey_results$ref_repor_per_year
new_het_fig$subs <- all_survey_results$num_pap_sub
new_het_fig$loc <- all_survey_results$loc_bin

new_het_fig$subs_binary <- 0
new_het_fig$subs_binary[new_het_fig$subs>6] <- 1
new_het_fig$reps_binary <- 0
new_het_fig$reps_binary[new_het_fig$reps>8] <- 1
new_het_fig$top_5_binary <- 0
new_het_fig$top_5_binary[new_het_fig$top_5>0] <- 1
new_het_fig$pos_binary <- 0
new_het_fig$pos_binary[new_het_fig$pos=="Postdoc/PhD"] <- 1
new_het_fig$pos_binary[new_het_fig$pos=="Assistant professor"] <- 1
new_het_fig$edit_binary <- 0
new_het_fig$edit_binary[new_het_fig$edit=="Yes"] <- 1
new_het_fig$gen_binary <- 0
new_het_fig$gen_binary[new_het_fig$gender=="Female"] <- 1
new_het_fig$loc_binary <- 0
new_het_fig$loc_binary[new_het_fig$loc=="United States/Canada"] <- 1

new_het_fig <- left_join(new_het_fig, fields_for_all, by="ID")
new_het_fig$field_binary <- 0
new_het_fig$field_binary[new_het_fig$V1=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V2=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V3=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V4=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V5=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V6=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V7=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V8=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V9=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V10=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V11=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V12=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V13=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V1=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V2=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V3=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V4=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V5=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V6=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V7=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V8=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V9=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V10=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V11=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V12=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V13=="Experimental economics"] <- 1



######## Subset to Only Experimental group ###########
all_survey_results <- new_het_fig[new_het_fig$field_binary == 1,]
new_het_fig_2 <- new_het_fig
new_het_fig <- all_survey_results


######## Dataset to analyze open text comments (saved in separate .xlsx files) ########
setwd(path)

incentives_comments <- import(paste0(inpath_comments,"comments about incentives.xlsx"))
colnames(incentives_comments)[2] <- "how_ref_reward_other"
improve_PR_comments <- import(paste0(inpath_comments,"comments about improving peer review.xlsx"))


incentives_comments <- left_join(all_survey_results, incentives_comments)
incentives_comments$career <- grepl("Career opportunity", incentives_comments$how_ref_reward_other_tags, fixed = TRUE)
nrow(incentives_comments[incentives_comments$career==TRUE,])

improve_PR_comments <- left_join(all_survey_results, improve_PR_comments)
improve_PR_comments <- improve_PR_comments[,c(100,149:153)]
improve_PR_comments <- improve_PR_comments[improve_PR_comments$sugg_improv_ref_exp!="-99",]

comments_df <- all_survey_results
comments_df$ID <- as.numeric(comments_df$ID)
comments_2  <- import(paste0(inpath_comments,"comments_combined.xlsx"))
colnames(comments_2)[1] <- "ID"
comments_2 <- left_join(comments_2, comments_df)
comments_2 <- comments_2[!is.na(comments_2$Progress),]
comments_2 <- comments_2[!is.na(comments_2$`Proposal Mapping`),c(1:4)]
nrow(comments_2[unique(comments_2$ID),])
comments_2_count <- count(comments_2$`Proposal Mapping`)

interactive_comments <- import(paste0(inpath_comments,"intreactive review comments.xlsx"))
interactive_comments_2 <- import(paste0(inpath_comments,"intreactive review comments 2.xlsx"))
interactive_comments$ID <- as.character(interactive_comments$ID)
interactive_comments_2$ID <- as.character(interactive_comments_2$ID)
colnames(interactive_comments)[2] <- "other_peer_rev_props_2"
colnames(interactive_comments)[2] <- "other_peer_rev_props_3"
interactive_comms <- left_join(all_survey_results,interactive_comments, by="ID")
interactive_comms_2 <- left_join(all_survey_results,interactive_comments_2, by="ID")




#######################################
#######################################
########## Figures and Stats ########## 
#######################################
#######################################

#######################################
########## Appendix Figure B.2 
#######################################
########## Correlation Matrix
corr_matrix_data <- all_survey_results[,c(110,33,34,51,49,37,60,63,64)]
corr_matrix_data$peer_rev_prop_4_remov_sen_anon <- as.numeric(corr_matrix_data$peer_rev_prop_4_remov_sen_anon)
corr_matrix_data$peer_rev_prop_4_remov_sen_anon <- corr_matrix_data$peer_rev_prop_4_remov_sen_anon -3
corr_matrix_data$peer_rev_prop_5_remov_assoc_edit_anon <- as.numeric(corr_matrix_data$peer_rev_prop_5_remov_assoc_edit_anon)
corr_matrix_data$peer_rev_prop_5_remov_assoc_edit_anon <- corr_matrix_data$peer_rev_prop_5_remov_assoc_edit_anon -3
corr_matrix_data$peer_rev_prop_8_all_rep_avail <- as.numeric(corr_matrix_data$peer_rev_prop_8_all_rep_avail)
corr_matrix_data$peer_rev_prop_8_all_rep_avail <- corr_matrix_data$peer_rev_prop_8_all_rep_avail -3

corr_matrix_data$peer_rev_hist_avail[corr_matrix_data$peer_rev_hist_avail=="5- Very favorable"] <- 5
corr_matrix_data$peer_rev_hist_avail[corr_matrix_data$peer_rev_hist_avail=="1- Not favorable\r\nat all"] <- 1
corr_matrix_data$peer_rev_hist_avail <- as.numeric(corr_matrix_data$peer_rev_hist_avail)
corr_matrix_data$peer_rev_hist_avail <- corr_matrix_data$peer_rev_hist_avail -3

corr_matrix_data$Open_peer_rev_pol[corr_matrix_data$Open_peer_rev_pol=="5- Very favorable"] <- 5
corr_matrix_data$Open_peer_rev_pol[corr_matrix_data$Open_peer_rev_pol=="1- Not favorable\r\nat all"] <- 1
corr_matrix_data$Open_peer_rev_pol <- as.numeric(corr_matrix_data$Open_peer_rev_pol)
corr_matrix_data$Open_peer_rev_pol <- corr_matrix_data$Open_peer_rev_pol -3

corr_matrix_data$author_resp_ref[corr_matrix_data$author_resp_ref=="5- Very favorable"] <- 5
corr_matrix_data$author_resp_ref[corr_matrix_data$author_resp_ref=="1- Not favorable\r\nat all"] <- 1
corr_matrix_data$author_resp_ref <- as.numeric(corr_matrix_data$author_resp_ref)
corr_matrix_data$author_resp_ref <- corr_matrix_data$author_resp_ref -3

corr_matrix_data$fav_double_blind[corr_matrix_data$fav_double_blind=="5- Very favorable"] <- 5
corr_matrix_data$fav_double_blind[corr_matrix_data$fav_double_blind=="1- Not favorable at all"] <- 1
corr_matrix_data$fav_double_blind[corr_matrix_data$fav_double_blind=="1- Not favorable  at all"] <- 1
corr_matrix_data$fav_double_blind <- as.numeric(corr_matrix_data$fav_double_blind)
corr_matrix_data$fav_double_blind <- corr_matrix_data$fav_double_blind -3

corr_matrix_data$fav_disq_rev[corr_matrix_data$fav_disq_rev=="5- Very favorable"] <- 5
corr_matrix_data$fav_disq_rev[corr_matrix_data$fav_disq_rev=="1- Not favorable at all"] <- 1
corr_matrix_data$fav_disq_rev[corr_matrix_data$fav_disq_rev=="1- Not favorable  at all"] <- 1
corr_matrix_data$fav_disq_rev <- as.numeric(corr_matrix_data$fav_disq_rev)
corr_matrix_data$fav_disq_rev <- corr_matrix_data$fav_disq_rev -3

colnames(corr_matrix_data) <- c("ID","Remove senior referee anonymity",
                                "Remove associate editor anonymity",
                                "Disclose review history",
                                "Open peer review",
                                "Share reports",
                                "Formal appeal procedure",
                                "Double-blind peer review",
                                "Allow disqualifying referees")

corr_matrix_data_2 <- corr_matrix_data
corr_matrix_data <- corr_matrix_data[,-1]


polychoric_corr <- psych::polychoric(corr_matrix_data)
cor_matrix <- polychoric_corr$rho

ggcorrplot(cor_matrix,
           hc.order = FALSE,         
           type = "lower",           
           lab = TRUE,               
           colors = c("red", "white", "blue"),
           outline.col = "gray")+ 
  scale_fill_gradient2(low = "white", high = "blue", mid = "#aed6f1", midpoint = 0.5, limits = c(-0.09, 1))


ggsave(paste0(outpath,"Fig_B_2 - correlation_plot.pdf"), width = 7, height = 7)



#######################################
########## Figure 1         ########### 
#######################################
regression_dataset <- corr_matrix_data_2
regression_dataset$`Remove senior referee anonymity` <- regression_dataset$`Remove senior referee anonymity`+3
regression_dataset$`Remove associate editor anonymity` <- regression_dataset$`Remove associate editor anonymity`+3
regression_dataset$`Disclose review history` <- regression_dataset$`Disclose review history`+3
regression_dataset$`Open peer review` <- regression_dataset$`Open peer review`+3
regression_dataset$`Share reports` <- regression_dataset$`Share reports`+3
regression_dataset$`Formal appeal procedure` <- regression_dataset$`Formal appeal procedure`+3
regression_dataset$`Double-blind peer review` <- regression_dataset$`Double-blind peer review`+3
regression_dataset$`Allow disqualifying referees` <- regression_dataset$`Allow disqualifying referees`+3

regression_dataset_2 <- as.data.frame(all_survey_results$ID)
colnames(regression_dataset_2) <- "ID"
regression_dataset_2$rev_hist_usefulness <- as.numeric(all_survey_results$peer_rev_prop_3_hist_avail)
regression_dataset_2$perc_ref_rep_qual_v_low <- as.numeric(all_survey_results$perc_ref_rep_qual_v_low)
regression_dataset_2$perc_ref_rep_qual_f_low <- as.numeric(all_survey_results$perc_ref_rep_qual_f_low)
regression_dataset_2$perc_ref_rep_qual_avg <- as.numeric(all_survey_results$perc_ref_rep_qual_avg)
regression_dataset_2$perc_ref_rep_qual_f_high <- as.numeric(all_survey_results$perc_ref_rep_qual_f_high)
regression_dataset_2$perc_ref_rep_qual_v_high <- as.numeric(all_survey_results$perc_ref_rep_qual_v_high)
regression_dataset_2$ref_for_friends <-all_survey_results$ref_for_friends
regression_dataset_2$subs_binary <- as.numeric(all_survey_results$subs_binary)
regression_dataset_2$reps_binary <- as.numeric(all_survey_results$reps_binary)
regression_dataset_2$top_5_binary <- as.numeric(all_survey_results$top_5_binary)
regression_dataset_2$pos_binary <- as.numeric(all_survey_results$pos_binary)
regression_dataset_2$edit_binary <- as.numeric(all_survey_results$edit_binary)
regression_dataset_2$gen_binary <- as.numeric(all_survey_results$gen_binary)
regression_dataset_2$loc_binary <- as.numeric(all_survey_results$loc_binary)

regression_dataset <- left_join(regression_dataset,regression_dataset_2)

summary_stats <- function(x) {
  # Remove NA values
  x <- na.omit(x)
  
  n <- length(x)
  mean_x <- mean(x)
  se_x <- sd(x) / sqrt(n)
  ci_margin <- qt(0.975, df = n - 1) * se_x
  
  # One-sample t-test against mu = 0
  t_test <- t.test(x, mu = 3)
  
  data.frame(
    mean = mean_x,
    se = se_x,
    ci_lower = mean_x - ci_margin,
    ci_upper = mean_x + ci_margin,
    p_value = t_test$p.value
  )
}

s1 <- summary_stats(regression_dataset$`Remove senior referee anonymity`)
s2 <- summary_stats(regression_dataset$`Remove associate editor anonymity`)
s3 <- summary_stats(regression_dataset$`Disclose review history`)
s4 <- summary_stats(regression_dataset$`Open peer review`)
s5 <- summary_stats(regression_dataset$`Share reports`)
s6 <- summary_stats(regression_dataset$`Formal appeal procedure`)
s7 <- summary_stats(regression_dataset$`Double-blind peer review`)
s8 <- summary_stats(regression_dataset$`Allow disqualifying referees`)


summary_stats_df <- rbind(s1, s2, s3, s4, s5, s6, s7, s8)
summary_stats_df$var <- c(
  "Remove senior referee anonymity",
  "Remove associate editor anonymity",
  "Disclose review history",
  "Open peer review",
  "Share reports",
  "Formal appeal procedure",
  "Double-blind peer review",
  "Allow disqualifying referees"
)

heading_rows <- data.frame(
  var = c(
    "<span style='font-size:12pt'><b>Identifiability</b></span>",
    " ",
    "<span style='font-size:12pt'><b>Open Communication</b></span>"
  ),
  mean = NA,
  se = NA,
  ci_lower = NA,
  ci_upper = NA,
  p_value = NA
)


summary_stats_df <- rbind(summary_stats_df, heading_rows)


ordered_levels <- c(
  "Formal appeal procedure",
  "Share reports",
  "Open peer review",
  "Disclose review history",
  "<span style='font-size:12pt'><b>Open Communication</b></span>",
  " ",
  "Allow disqualifying referees",
  "Remove associate editor anonymity",
  "Remove senior referee anonymity",
  "Double-blind peer review",
  "<span style='font-size:12pt'><b>Identifiability</b></span>"
)

summary_stats_df$var <- factor(summary_stats_df$var, levels = ordered_levels)

# Plot
ggplot(summary_stats_df, aes(x = var, y = mean)) +
  geom_point(position = position_dodge(width = 0.5), na.rm = TRUE) +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper),
                width = 0.2, position = position_dodge(width = 0.5), na.rm = TRUE) +
  geom_hline(yintercept = 3, color = "red", linetype = "dashed") + 
  coord_flip() +
  labs(title = "", y = "Coefficients", x = "") +
  theme_minimal() +
  theme(
    axis.text.y = ggtext::element_markdown(margin = margin(r = 10)),
    axis.line = element_line(color = "black"),  
    panel.border = element_blank(), 
    panel.grid = element_blank(),
  )+
  ylim(1.9,4.1)


ggsave(paste0(outpath,"Fig_1 - Coefficient plot - means against neutral value (=3).pdf"), width = 7, height=6)




#######################################
########## LCA Analysis  ############## 
#######################################
set.seed(123)
data_LCA <- all_survey_results[,c(33,34,51,49,37,60)]
data_LCA$peer_rev_hist_avail[data_LCA$peer_rev_hist_avail=="5- Very favorable"] <- 5
data_LCA$peer_rev_hist_avail[data_LCA$peer_rev_hist_avail=="1- Not favorable\r\nat all"] <- 1

data_LCA$Open_peer_rev_pol[data_LCA$Open_peer_rev_pol=="5- Very favorable"] <- 5
data_LCA$Open_peer_rev_pol[data_LCA$Open_peer_rev_pol=="1- Not favorable\r\nat all"] <- 1

data_LCA$author_resp_ref[data_LCA$author_resp_ref=="5- Very favorable"] <- 5
data_LCA$author_resp_ref[data_LCA$author_resp_ref=="1- Not favorable\r\nat all"] <- 1

# Convert all variables to factors (poLCA expects categorical variables as factors)
data_LCA[] <- lapply(data_LCA, as.factor)

# Define the formula for poLCA
f <- as.formula(paste("cbind(", paste(colnames(data_LCA), collapse = ", "), ") ~ 1"))

# Run LCA models with 1 to 6 classes and store BIC values
results <- list()
bic_values <- numeric()
for (k in 1:6) {
  cat("Fitting model with", k, "classes...\n")
  model <- poLCA(f, data_LCA, nclass = k, maxiter = 1000, nrep = 10, verbose = FALSE, graphs = FALSE)
  results[[k]] <- model
  bic_values[k] <- model$bic
}

# Identify the best model (lowest BIC)
best_k <- which.min(bic_values)
best_model <- results[[best_k]]
cat("\nBest model has", best_k, "classes (lowest BIC =", round(bic_values[best_k], 2), ")\n")

# Add predicted class membership to the original data
data_LCA$LCA_class <- best_model$predclass

print(best_model$probs)

prob_list <- lapply(best_model$probs, function(x) as.data.frame(x))
for (i in seq_along(prob_list)) {
  prob_list[[i]]$Variable <- names(best_model$probs)[i]
  prob_list[[i]]$Level <- 1:3
}
prob_df <- do.call(rbind, prob_list)
prob_long <- melt(prob_df, id.vars = c("Variable", "Level"), variable.name = "Class", value.name = "Probability")


#######################################
####### Appendix Figure B.3
#######################################
### Visualize class membership distribution
# Create a table of class memberships
class_counts <- table(data_LCA$LCA_class)

# Reorder the table to the order: 2, 1, 3
reordered_counts <- class_counts[c("2", "1", "3")]

# Define custom colors for the reordered classes
custom_colors <- c("#B22222", "lightgray", "#4682B4")

# Define new class names in matching order
class_labels <- c("Traditionalists", "Incrementalists", "Reformists")

# Create a data frame from the vector
df <- data.frame(
  Class = class_labels,
  Count = as.numeric(reordered_counts)
)

# Set factor levels for Class to control order in the plot
df$Class <- factor(df$Class, levels = class_labels)

# Save the plot to a PDF
ggplot(df, aes(x = Class, y = Count, fill = Class)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = custom_colors) +
  labs( title = "",
    x = "",
    y = "Count"
  ) +
  theme_minimal()+
  theme(legend.position = "none",
        panel.grid = element_blank(),
        axis.line = element_line(color = "black"),
  )

ggsave(
  filename = paste0(outpath, "Fig_B_3 - class_membership_plot.pdf"),
  width = 7,
  height = 5
)



#######################################
####### Figure 2
#######################################
var_labels <- c(peer_rev_prop_4_remov_sen_anon = "Remove senior referee anonymity",
                peer_rev_prop_5_remov_assoc_edit_anon="Remove associate editor anonymity",
                peer_rev_hist_avail="Disclose review history",
                Open_peer_rev_pol="Open peer review",
                peer_rev_prop_8_all_rep_avail="Share reports",
                author_resp_ref="Formal appeal procedure")

prob_long$Variable <- factor(prob_long$Variable, levels = names(var_labels), labels = var_labels)

prob_long$Level <- factor(prob_long$Level,
                          levels = c("2", "1", "3"),
                          labels = c("Traditionalists", "Incrementalists", "Reformists"))

class_colors <- c("Traditionalists" = "#B22222", 
                  "Incrementalists" = "lightgray", 
                  "Reformists" = "#4682B4")

# Plot
ggplot(prob_long, aes(x = Probability, y = Class, fill = factor(Level))) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_grid(Variable ~ Level, labeller = labeller(Variable = label_wrap_gen(width = 18))) +
  scale_fill_brewer(palette = "Set3") +
  theme_minimal(base_size = 12) +
  theme(
    strip.text.x = element_text(face = "bold", size = 13),  
    strip.text.y = element_text(size = 11),                 
    legend.position = "none",
    panel.border = element_blank(), 
    panel.grid = element_blank(),
  ) +
  labs(
    x = "Probability",
    fill = "Class",
    y = "Response Level"
  ) +
  scale_fill_manual(values = class_colors)


ggsave(paste0(outpath,"Fig_2 - LCA_probabilities_results.pdf"), width=11, height=9)


#######################################
####### Figure 3
#######################################
### LCA Classes by Demographics
all_survey_results_w_LCA <- all_survey_results
all_survey_results_w_LCA$index  <- 1:nrow(all_survey_results_w_LCA)
data_LCA$index <- 1:nrow(data_LCA)
data_LCA_2 <- data_LCA[,c(7,8)]
all_survey_results_w_LCA <- left_join(all_survey_results_w_LCA,data_LCA_2)
all_survey_results_w_LCA <- all_survey_results_w_LCA[,c(128:134,150)]
all_survey_results_w_LCA$Class_1 <- 0
all_survey_results_w_LCA$Class_1[all_survey_results_w_LCA$LCA_class==1] <- 1
all_survey_results_w_LCA$Class_2 <- 0
all_survey_results_w_LCA$Class_2[all_survey_results_w_LCA$LCA_class==2] <- 1
all_survey_results_w_LCA$Class_3 <- 0
all_survey_results_w_LCA$Class_3[all_survey_results_w_LCA$LCA_class==3] <- 1

### Class 1
model1 <- glm(Class_1 ~ gen_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model1)
model2 <- glm(Class_1 ~ pos_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model2)
model3 <- glm(Class_1 ~ loc_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model3)
model4 <- glm(Class_1 ~ edit_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model4)
model5 <- glm(Class_1 ~ top_5_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model5)
model6 <- glm(Class_1 ~ reps_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model6)
model7 <- glm(Class_1 ~ subs_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model7)
model8 <- glm(Class_1 ~ gen_binary + pos_binary + loc_binary + edit_binary + top_5_binary + reps_binary + subs_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model8)


coef1 <- tidy(model1) %>% mutate(model = "Individual")
coef2 <- tidy(model2) %>% mutate(model = "Individual")
coef3 <- tidy(model3) %>% mutate(model = "Individual")
coef4 <- tidy(model4) %>% mutate(model = "Individual")
coef5 <- tidy(model5) %>% mutate(model = "Individual")
coef6 <- tidy(model6) %>% mutate(model = "Individual")
coef7 <- tidy(model7) %>% mutate(model = "Individual")
coef8 <- tidy(model8) %>% mutate(model = "Joint")

all_coefs <- bind_rows(coef1, coef2, coef3, coef4, coef5, coef6, coef7#, coef8
)

all_coefs_1 <- all_coefs


### Class 2
model1 <- glm(Class_2 ~ gen_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model1)
model2 <- glm(Class_2 ~ pos_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model2)
model3 <- glm(Class_2 ~ loc_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model3)
model4 <- glm(Class_2 ~ edit_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model4)
model5 <- glm(Class_2 ~ top_5_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model5)
model6 <- glm(Class_2 ~ reps_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model6)
model7 <- glm(Class_2 ~ subs_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model7)
model8 <- glm(Class_2 ~ gen_binary + pos_binary + loc_binary + edit_binary + top_5_binary + reps_binary + subs_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model8)


coef1 <- tidy(model1) %>% mutate(model = "Individual")
coef2 <- tidy(model2) %>% mutate(model = "Individual")
coef3 <- tidy(model3) %>% mutate(model = "Individual")
coef4 <- tidy(model4) %>% mutate(model = "Individual")
coef5 <- tidy(model5) %>% mutate(model = "Individual")
coef6 <- tidy(model6) %>% mutate(model = "Individual")
coef7 <- tidy(model7) %>% mutate(model = "Individual")
coef8 <- tidy(model8) %>% mutate(model = "Joint")

all_coefs <- bind_rows(coef1, coef2, coef3, coef4, coef5, coef6, coef7#, coef8
)

all_coefs_2 <- all_coefs


### Class 3
model1 <- glm(Class_3 ~ gen_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model1)
model2 <- glm(Class_3 ~ pos_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model2)
model3 <- glm(Class_3 ~ loc_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model3)
model4 <- glm(Class_3 ~ edit_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model4)
model5 <- glm(Class_3 ~ top_5_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model5)
model6 <- glm(Class_3 ~ reps_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model6)
model7 <- glm(Class_3 ~ subs_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model7)
model8 <- glm(Class_3 ~ gen_binary + pos_binary + loc_binary + edit_binary + top_5_binary + reps_binary + subs_binary, data = all_survey_results_w_LCA, family = binomial)
summary(model8)


coef1 <- tidy(model1) %>% mutate(model = "Individual")
coef2 <- tidy(model2) %>% mutate(model = "Individual")
coef3 <- tidy(model3) %>% mutate(model = "Individual")
coef4 <- tidy(model4) %>% mutate(model = "Individual")
coef5 <- tidy(model5) %>% mutate(model = "Individual")
coef6 <- tidy(model6) %>% mutate(model = "Individual")
coef7 <- tidy(model7) %>% mutate(model = "Individual")
coef8 <- tidy(model8) %>% mutate(model = "Joint")

all_coefs <- bind_rows(coef1, coef2, coef3, coef4, coef5, coef6, coef7#, coef8
)

all_coefs_3 <- all_coefs


### COMBINED ALL
all_coefs_1$model <- "Incrementalists"
all_coefs_2$model <- "Traditionalists"
all_coefs_3$model <- "Reformists"


all_coefs <- bind_rows(all_coefs_1, all_coefs_2, all_coefs_3)


var_labels <- c(
  "gen_binary" = "Female",
  "pos_binary" = "Junior",
  "loc_binary" = "US/Canada",
  "edit_binary" = "Editor",
  "top_5_binary" = "Top 5 reviewer",
  "reps_binary" = "Active reviewer",
  "subs_binary" = "Active author"
)

all_coefs <- all_coefs %>%
  dplyr::mutate(term = str_replace(term, "gen_binary", "Female"),
                term = str_replace(term, "pos_binary", "Junior"),
                term = str_replace(term, "loc_binary", "US/Canada"),
                term = str_replace(term, "edit_binary", "Editor"),
                term = str_replace(term, "top_5_binary", "Top 5 reviewer"),
                term = str_replace(term, "reps_binary", "Active reviewer"),
                term = str_replace(term, "subs_binary", "Active author"))

all_coefs <- all_coefs %>%
  dplyr::mutate(term = factor(term, levels = c("Active author","Active reviewer","Top 5 reviewer","Editor", "US/Canada","Junior", "Female")))



class_colors <- c(
  "Traditionalists" = "#B22222", 
  "Incrementalists" = "darkgray", 
  "Reformists" = "#4682B4"
)

all_coefs$model <- factor(all_coefs$model, levels = names(class_colors))

ggplot(all_coefs %>% filter(term != "(Intercept)"), 
       aes(x = term, y = estimate, color = model)) +
  geom_point(position = position_dodge(width = 0.5)) + 
  geom_errorbar(aes(ymin = estimate - 1.96 * std.error, 
                    ymax = estimate + 1.96 * std.error),
                width = 0.2, position = position_dodge(width = 0.5)) +
  coord_flip() +
  scale_color_manual(
    values = class_colors,
    guide = guide_legend(reverse = TRUE),
    name = NULL  
  ) + 
  labs(title = "", y = "Coefficients", x = "") +
  theme_minimal() +
  theme(
    axis.text.y = ggtext::element_markdown(margin = margin(r = 10)),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
  ) +
  geom_hline(yintercept = 0, color = "black", linetype = "dotted") +  
  scale_y_continuous(
    limits = c(-1.5, 1.5),
    breaks = c(-1.5, -1, -0.5, 0, 0.5, 1, 1.5)
  )


ggsave(paste0(outpath,"Fig_3 - Class_All_demog_pred_coeff_plot.pdf"), width = 7, height=6)



#######################################
####### Appendix Figure B.4
#######################################
########### Demographic Bar Graphs across LCA classes
binary_vars <- names(all_survey_results_w_LCA)
binary_vars <- binary_vars[grepl("_binary$", binary_vars)]

# Compute group-wise means and reshape
mean_df <- all_survey_results_w_LCA %>%
  group_by(LCA_class) %>%
  dplyr::summarise(across(all_of(binary_vars), ~mean(.x, na.rm = TRUE))) %>%
  pivot_longer(cols = all_of(binary_vars), 
               names_to = "variable", 
               values_to = "mean_share")

mean_df <- mean_df %>%
  dplyr::mutate(variable = str_replace(variable, "gen_binary", "Female"),
                variable = str_replace(variable, "pos_binary", "Junior"),
                variable = str_replace(variable, "loc_binary", "US/Canada"),
                variable = str_replace(variable, "edit_binary", "Editor"),
                variable = str_replace(variable, "top_5_binary", "Top 5 reviewer"),
                variable = str_replace(variable, "reps_binary", "Active reviewer"),
                variable = str_replace(variable, "subs_binary", "Active author"))

mean_df <- mean_df %>%
  dplyr::mutate(variable = factor(variable, levels = c("Active author","Active reviewer","Top 5 reviewer","Editor", "US/Canada","Junior", "Female")))

mean_df$LCA_class <- factor(mean_df$LCA_class,
                            levels = c("2", "1", "3"),
                            labels = c("Traditionalists", "Incrementalists", "Reformists"))

custom_colors <- c("#B22222", "lightgray", "#4682B4")



# Plot
ggplot(mean_df, aes(x = variable, y = mean_share, fill = as.factor(LCA_class))) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(x = "", y = "Share", fill = "LCA Class") +
  theme_minimal() +
  theme(
    axis.text.y = ggtext::element_markdown(margin = margin(r = 10)),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_fill_manual(values = custom_colors) +
  guides(fill = guide_legend(title = NULL))

ggsave(paste0(outpath,"Fig_B_4 - Dempographic_shares_by_LCA_Class_bar_graph.pdf"), width = 7, height=6)



#######################################
########## Statistics for number favorable and unfavorable
#######################################
#### Counts of respondents <= 2 (unfavorable) and >= 4 (favorable)

## Double blind
nrow(regression_dataset[!is.na(regression_dataset$`Double-blind peer review`),])
# Share unfavorable 
nrow(regression_dataset[regression_dataset$`Double-blind peer review`<3&!is.na(regression_dataset$`Double-blind peer review`),])/nrow(regression_dataset[!is.na(regression_dataset$`Double-blind peer review`),])
# Share favorable
nrow(regression_dataset[regression_dataset$`Double-blind peer review`>3&!is.na(regression_dataset$`Double-blind peer review`),])/nrow(regression_dataset[!is.na(regression_dataset$`Double-blind peer review`),])


## Remove senior referee anonymity 
nrow(regression_dataset[!is.na(regression_dataset$`Remove senior referee anonymity`),])
# Share not useful 
nrow(regression_dataset[regression_dataset$`Remove senior referee anonymity`<3&!is.na(regression_dataset$`Remove senior referee anonymity`),])/nrow(regression_dataset[!is.na(regression_dataset$`Remove senior referee anonymity`),])
# Share useful
nrow(regression_dataset[regression_dataset$`Remove senior referee anonymity`>3&!is.na(regression_dataset$`Remove senior referee anonymity`),])/nrow(regression_dataset[!is.na(regression_dataset$`Remove senior referee anonymity`),])


## Remove associate editor anonymity
nrow(regression_dataset[!is.na(regression_dataset$`Remove associate editor anonymity`),])
# Share not useful 
nrow(regression_dataset[regression_dataset$`Remove associate editor anonymity`<3&!is.na(regression_dataset$`Remove associate editor anonymity`),])/nrow(regression_dataset[!is.na(regression_dataset$`Remove associate editor anonymity`),])
# Share useful
nrow(regression_dataset[regression_dataset$`Remove associate editor anonymity`>3&!is.na(regression_dataset$`Remove associate editor anonymity`),])/nrow(regression_dataset[!is.na(regression_dataset$`Remove associate editor anonymity`),])


## Share rejecting or considering rejecting due to conflict of interest
(sum(str_detect(all_survey_results$rej_ref_req_reasons, stringr::regex("Conflict of interest", ignore_case = TRUE)),na.rm = TRUE)+sum(str_detect(all_survey_results$rej_ref_req_temp_reasons, stringr::regex("Conflict of interest", ignore_case = TRUE)),na.rm = TRUE))/nrow(all_survey_results)


## Conflict of Interest
nrow(regression_dataset[!is.na(regression_dataset$ref_for_friend),])
# Never
nrow(regression_dataset[regression_dataset$ref_for_friends=="This should never happen.",])/nrow(regression_dataset[!is.na(regression_dataset$ref_for_friend),])
# As little as possible
nrow(regression_dataset[regression_dataset$ref_for_friends=="This should happen as little as possible but cannot be avoided sometimes.",])/nrow(regression_dataset[!is.na(regression_dataset$ref_for_friend),])
# Fine if editor knows
nrow(regression_dataset[regression_dataset$ref_for_friends=="This is not a problem as long as the editor is aware of the potential conflict of interest.",])/nrow(regression_dataset[!is.na(regression_dataset$ref_for_friend),])
# Fine regardless
nrow(regression_dataset[regression_dataset$ref_for_friends=="This is not a problem and there is no reason to inform the editor.",])/nrow(regression_dataset[!is.na(regression_dataset$ref_for_friend),])


## Disqualify referees
nrow(regression_dataset[!is.na(regression_dataset$`Allow disqualifying referees`),])
# Share unfavorable 
nrow(regression_dataset[regression_dataset$`Allow disqualifying referees`<3&!is.na(regression_dataset$`Allow disqualifying referees`),])/nrow(regression_dataset[!is.na(regression_dataset$`Allow disqualifying referees`),])
# Share favorable
nrow(regression_dataset[regression_dataset$`Allow disqualifying referees`>3&!is.na(regression_dataset$`Allow disqualifying referees`),])/nrow(regression_dataset[!is.na(regression_dataset$`Allow disqualifying referees`),])


## Disc rev hist
nrow(regression_dataset[!is.na(regression_dataset$`Disclose review history`),])
# Share unfavorable 
nrow(regression_dataset[regression_dataset$`Disclose review history`<3&!is.na(regression_dataset$`Disclose review history`),])/nrow(regression_dataset[!is.na(regression_dataset$`Disclose review history`),])
# Share favorable
nrow(regression_dataset[regression_dataset$`Disclose review history`>3&!is.na(regression_dataset$`Disclose review history`),])/nrow(regression_dataset[!is.na(regression_dataset$`Disclose review history`),])


## Alternative review history
s_extra_1 <- summary_stats(regression_dataset$rev_hist_usefulness)
nrow(regression_dataset[!is.na(regression_dataset$rev_hist_usefulness),])
# Share not useful 
nrow(regression_dataset[regression_dataset$rev_hist_usefulness<3&!is.na(regression_dataset$rev_hist_usefulness),])/nrow(regression_dataset[!is.na(regression_dataset$rev_hist_usefulness),])
# Share useful
nrow(regression_dataset[regression_dataset$rev_hist_usefulness>3&!is.na(regression_dataset$rev_hist_usefulness),])/nrow(regression_dataset[!is.na(regression_dataset$rev_hist_usefulness),])


## Correlation between review history usefulness and favorability
rev_hist_comparisons <- all_survey_results[,c(32,51)]
rev_hist_comparisons$peer_rev_prop_3_hist_avail <- as.numeric(rev_hist_comparisons$peer_rev_prop_3_hist_avail)
rev_hist_comparisons$peer_rev_hist_avail[rev_hist_comparisons$peer_rev_hist_avail=="5- Very favorable"] <- 5
rev_hist_comparisons$peer_rev_hist_avail[rev_hist_comparisons$peer_rev_hist_avail=="1- Not favorable\r\nat all"] <- 1
rev_hist_comparisons$peer_rev_hist_avail <- as.numeric(rev_hist_comparisons$peer_rev_hist_avail)
#corr.test(rev_hist_comparisons$peer_rev_hist_avail,rev_hist_comparisons$peer_rev_prop_3_hist_avail)
polychoric_result <- polychoric(cbind(rev_hist_comparisons$peer_rev_hist_avail,
                                      rev_hist_comparisons$peer_rev_prop_3_hist_avail))
polychoric_result$rho


## Open Peer Review
nrow(regression_dataset[!is.na(regression_dataset$`Open peer review`),])
# Share unfavorable 
nrow(regression_dataset[regression_dataset$`Open peer review`<3&!is.na(regression_dataset$`Open peer review`),])/nrow(regression_dataset[!is.na(regression_dataset$`Open peer review`),])
# Share favorable
nrow(regression_dataset[regression_dataset$`Open peer review`>3&!is.na(regression_dataset$`Open peer review`),])/nrow(regression_dataset[!is.na(regression_dataset$`Open peer review`),])


## Number of respondents reporting inconsistent or unrealistic demands
(sum(str_detect(all_survey_results$low_qual_char, stringr::regex("Inconsistent demands|Unrealistic demands", ignore_case = TRUE)),na.rm = TRUE))/nrow(all_survey_results)


## Formal appeal process
nrow(regression_dataset[!is.na(regression_dataset$`Formal appeal procedure`),])
# Share unfavorable 
nrow(regression_dataset[regression_dataset$`Formal appeal procedure`<3&!is.na(regression_dataset$`Formal appeal procedure`),])/nrow(regression_dataset[!is.na(regression_dataset$`Formal appeal procedure`),])
# Share favorable
nrow(regression_dataset[regression_dataset$`Formal appeal procedure`>3&!is.na(regression_dataset$`Formal appeal procedure`),])/nrow(regression_dataset[!is.na(regression_dataset$`Formal appeal procedure`),])


## Share reports
nrow(regression_dataset[!is.na(regression_dataset$`Share reports`),])
# Share unfavorable 
nrow(regression_dataset[regression_dataset$`Share reports`<3&!is.na(regression_dataset$`Share reports`),])/nrow(regression_dataset[!is.na(regression_dataset$`Share reports`),])
# Share favorable
nrow(regression_dataset[regression_dataset$`Share reports`>3&!is.na(regression_dataset$`Share reports`),])/nrow(regression_dataset[!is.na(regression_dataset$`Share reports`),])







#######################################
########## Appendix Figure A.1 
#######################################
### Distribution of responses across recruitment channels
surveys <- as.data.frame(all_survey_results_2$survey_num[all_survey_results$Progress=="100"])
colnames(surveys) <- "survey"
n_surveys <- nrow(surveys) 
surveys_count <- count(surveys$survey)
surveys_count$freq[surveys_count$x=="Survey EEA1"] <- surveys_count$freq[surveys_count$x=="Survey EEA1"] + surveys_count$freq[surveys_count$x=="Survey EEA2"]
surveys_count <- surveys_count[-5,]
surveys_count$perc <- (surveys_count$freq/n_surveys)*100
surveys_count$x <- as.character(surveys_count$x)
surveys_count$x[surveys_count$x=="Survey MM1"] <- "Mail merge 1"
surveys_count$x[surveys_count$x=="Survey MM2"] <- "Mail merge 2"
surveys_count$x[surveys_count$x=="Survey ESA"] <- "ESA forum"
surveys_count$x[surveys_count$x=="Survey DT"] <- "DT forum"
surveys_count$x[surveys_count$x=="Survey EEA1"] <-  wrapper("EEA website + social media", width = 15)
surveys_count$x[surveys_count$x=="Survey CESifo"] <- "CESifo network"
surveys_count$x[surveys_count$x=="Survey CEPR"] <- "CEPR network"
surveys_count$x[surveys_count$x=="Survey Pilot"] <- "Pilot"


surveys_count$x <- factor(surveys_count$x, levels=c("Pilot", "ESA forum", "DT forum", "CESifo network", "CEPR network", wrapper("EEA website + social media", width = 15), "Mail merge 1", "Mail merge 2"))

ggplot(surveys_count, aes(x=x, y=freq))+geom_bar(stat="identity")+xlab("")+ylab("Number of responses")+
  theme(plot.title = element_text(hjust = 0.5), panel.background = element_blank(), panel.grid = element_blank(), axis.line = element_line(), axis.text=element_text(size=18), axis.title=element_text(size=18,face="bold"), 
        axis.text.x = element_text(angle = 45, hjust = 1)) + 
  scale_y_continuous(breaks = c(0, 100, 200, 300, 400, 500, 600, 700), limits=c(0,701))

ggsave(paste0(outpath,"Fig_A_1 - Survey Links Figure.pdf"), width=10, height=6, dpi=700)



#######################################
########## Appendix Figure B.1 
#######################################
### Characteristics of low-quality reports
low_char <- as.data.frame(all_survey_results$low_qual_char)
low_char <- as.data.frame(low_char[!is.na(low_char)])
colnames(low_char) <- "low_char"
low_char_response <- nrow(low_char)
low_char <- str_split(low_char$low_char, ",")
low_char <- as.data.frame(unlist(low_char))
colnames(low_char) <- "low_char"
low_char_count <- count(low_char)
colnames(low_char_count) <- c("char", "count")
low_char_count <- low_char_count[c(1,7,8,4,6,2,5,3),]
row.names(low_char_count) <- NULL
low_char_count$char <- as.character(low_char_count$char)
low_char_count$char[low_char_count$char == "Inaccurate statements about what the paper does or does not do"] <-"Inaccurate\ncomments"
low_char_count$char[low_char_count$char == "Very vague and unconstructive comments"] <- "Unconstructive\ncomments"
low_char_count$char[low_char_count$char == "Written with an aggressive tone"] <-"Aggressive\ntone"
low_char_count$char[low_char_count$char == "Overly short report"] <- "Overly\nshort report"
low_char_count$char[low_char_count$char == "Unrealistic demands"] <- "Unrealistic\ndemands"
low_char_count$char[low_char_count$char == "Inconsistent demands"] <- "Inconsistent\ndemands"
low_char_count$char[low_char_count$char == "Personal insults"] <- "Personal\ninsults"
low_char_count$char[low_char_count$char == "Other - please specify:"] <- "Other"
low_char_count$perc <- (low_char_count$count/low_char_response)*100
low_char_count$char <- factor(x=low_char_count$char, levels=c( "Inaccurate\ncomments",  "Unconstructive\ncomments",
                                                               "Aggressive\ntone", "Overly\nshort report", "Unrealistic\ndemands", "Inconsistent\ndemands",
                                                               "Personal\ninsults", "Other"))


ggplot(low_char_count, aes(x=char, y=perc))+geom_bar(stat = "identity")+xlab("")+
  ylab("Percentage of responses")+ 
  theme(axis.line = element_line(colour = "black"), panel.background = element_blank(), axis.text =element_text(size=18), axis.title=element_text(size=18,face="bold"), axis.text.x = element_text(size=18))+  ylim(0,100)

ggsave(paste0(outpath,"Fig_B_1 - Characteristics of Low Quality Referee Reports - experimental group.pdf"), width = 16, height = 5.5)



#######################################
########## Appendix Figure B.5
#######################################
########## Write-in comments and World Cloud
##### Statistics on write-in comments
comments_df <- all_survey_results
comments_df$ID <- as.numeric(comments_df$ID)
comments_2  <- import(paste0(inpath_comments,"comments_combined.xlsx"))
colnames(comments_2)[1] <- "ID"
comments_2 <- left_join(comments_2, comments_df)
comments_2 <- comments_2[!is.na(comments_2$Progress),]
comments_2 <- comments_2[!is.na(comments_2$`Proposal Mapping`),c(1:4)]
comments_2 <- comments_2[comments_2$Column!="how_ref_reward_other",]
nrow(comments_2[unique(comments_2$ID),])
comments_2_count <- count(comments_2$`Proposal Mapping`)



set.seed(44332211)
# Combine all comments into one text string
text <- paste(comments_2$Comment, collapse = " ")

# Create corpus
corpus <- Corpus(VectorSource(text))

# Define custom stop words (you can expand this list further)
custom_stopwords <- c(stopwords("english"), 
                      "can", "may", "also", "one", "will", "get", 
                      "just", "like", "use", "used", "even", "well", 
                      "make", "much", "still", "really", "thing", 
                      "things", "done", "now", "see", "etc")

# Clean text
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, removePunctuation)
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords, custom_stopwords)
corpus <- tm_map(corpus, stripWhitespace)
corpus <- tm_map(corpus, stemDocument) 

# Create term-document matrix
tdm <- TermDocumentMatrix(corpus)
matrix <- as.matrix(tdm)
word_freqs <- sort(rowSums(matrix), decreasing = TRUE)
df <- data.frame(word = names(word_freqs), freq = word_freqs)

# Plot word cloud
png(paste0(outpath, "Fig_B_5 - wordcloud of comments - stemmed words.png"), width = 1700, height = 1700, res = 400)

par(mar = rep(0, 4))  # No margins

wordcloud(words = df$word,
          freq = df$freq,
          min.freq = 1,
          max.words = 100,
          scale = c(4, 0.5),
          colors = brewer.pal(8, "Dark2"))

dev.off()



#######################################
########## Appendix Figure B.6 
#######################################

# Define the transparency-related category labels (without the numbers)
transparency_labels <- c(
  "Acknowledge names of exceptional referees in annual report",  # visibility
  "Editors explain to referees how reports affected decision",    # sharing info
  "Editors explain rationale for not desk rejecting and referee selection",  # editorial transparency
  "More interactive review process",                             # open communication
  "Share decision letters and referee reports with referees",     # report transparency
  "Feedback from authors to referees about report quality",       # report feedback transparency
  "Disclose all editorial communications and conflicts to referees", # conflict transparency
  "Public reputation scores for referees based on performance",   # visibility
  "Share review history of published papers",                     # review disclosure
  "Allow author response to decisions and reports",               # open communication
  "Intra-publisher journal partnership to share reports",         # inter-journal transparency
  "Post-publication peer review",                                 # open review
  "Allow authors to oppose referees or editors",                  # process transparency
  "Share referee’s letter to the editor with authors",            # review transparency
  "Publish handling editor name",                                 # editor identity disclosure
  "Share review history of rejected papers",                      # disclosure of peer review
  "Better editorial explanations to authors about decisions",     # transparency in reasoning
  "Publish more journal performance statistics",                  # institutional transparency
  "Publish referees’ names on accepted papers",                   # identity transparency
  "Double-blind reviewing as standard",                           # anonymity policy
  "Clear conflict-of-interest guidelines for referees",           # transparency of bias
  "Enact measures to make submissions truly double-blind",        # anonymity enforcement
  "Remove anonymity during appeal process to deter low-quality reports" # identity transparency
)

# Create the binary variable based on exact matching of category labels
comments_2$transparency_binary <- ifelse(comments_2$`Proposal Mapping` %in% transparency_labels, 1, 0)

nrow(comments_2[comments_2$transparency_binary==1,])

# -------------------------------
# Separate text by transparency category
# -------------------------------
transparency_text <- paste(comments_2$Comment[comments_2$transparency_binary == 1], collapse = " ")
non_transparency_text <- paste(comments_2$Comment[comments_2$transparency_binary == 0], collapse = " ")

# -------------------------------
# Function to clean and process corpus
# -------------------------------
clean_corpus <- function(text, stem = FALSE) {
  corpus <- Corpus(VectorSource(text))
  
  custom_stopwords <- c(stopwords("english"), 
                        "can", "may", "also", "one", "will", "get", 
                        "just", "like", "use", "used", "even", "well", 
                        "make", "much", "still", "really", "thing", 
                        "things", "done", "now", "see", "etc")
  
  corpus <- tm_map(corpus, content_transformer(tolower))
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, removeWords, custom_stopwords)
  corpus <- tm_map(corpus, stripWhitespace)
  
  if (stem) {
    corpus <- tm_map(corpus, stemDocument)
  }
  
  return(corpus)
}

# -------------------------------
# Function to find unique frequent words in transparency comments
# -------------------------------
get_unique_words <- function(transparency_text, non_text, stem = FALSE) {
  trans_corpus <- clean_corpus(transparency_text, stem = stem)
  non_corpus   <- clean_corpus(non_text, stem = stem)
  
  trans_tdm <- TermDocumentMatrix(trans_corpus)
  non_tdm   <- TermDocumentMatrix(non_corpus)
  
  trans_matrix <- as.matrix(trans_tdm)
  non_matrix   <- as.matrix(non_tdm)
  
  trans_freq <- rowSums(trans_matrix)
  non_freq   <- rowSums(non_matrix)
  
  # Retain only frequent words in transparency and low/absent in non-transparency
  threshold <- 3  # Minimum frequency in transparency
  transparency_only <- trans_freq[trans_freq >= threshold & 
                                    (!names(trans_freq) %in% names(non_freq) | non_freq[names(trans_freq)] < 1)]
  
  df <- data.frame(word = names(transparency_only), freq = transparency_only)
  return(df)
}

# -------------------------------
# Create and save word clouds
# -------------------------------
# --- Stemmed ---
df_stemmed <- get_unique_words(transparency_text, non_transparency_text, stem = TRUE)

png(paste0(outpath, "Fig_B_6 - wordcloud_transparency_unique_stemmed.png"),
    width = 3000, height = 3000, res = 400)

par(mar = rep(0,4), oma = rep(0,4))

wordcloud(
  words = df_stemmed$word,
  freq = df_stemmed$freq,
  min.freq = 1,
  max.words = 100,
  scale = c(4, 0.5),
  random.order = FALSE,
  colors = brewer.pal(8, "Dark2")
)

dev.off()





###########################################
### Table B.1
###########################################
regression_dataset <- corr_matrix_data_2
regression_dataset$`Remove senior referee anonymity` <- regression_dataset$`Remove senior referee anonymity`+3
regression_dataset$`Remove associate editor anonymity` <- regression_dataset$`Remove associate editor anonymity`+3
regression_dataset$`Disclose review history` <- regression_dataset$`Disclose review history`+3
regression_dataset$`Open peer review` <- regression_dataset$`Open peer review`+3
regression_dataset$`Share reports` <- regression_dataset$`Share reports`+3
regression_dataset$`Formal appeal procedure` <- regression_dataset$`Formal appeal procedure`+3
regression_dataset$`Double-blind peer review` <- regression_dataset$`Double-blind peer review`+3
regression_dataset$`Allow disqualifying referees` <- regression_dataset$`Allow disqualifying referees`+3

regression_dataset_2 <- as.data.frame(all_survey_results$ID)
colnames(regression_dataset_2) <- "ID"
regression_dataset_2$rev_hist_usefulness <- as.numeric(all_survey_results$peer_rev_prop_3_hist_avail)
regression_dataset_2$perc_ref_rep_qual_v_low <- as.numeric(all_survey_results$perc_ref_rep_qual_v_low)
regression_dataset_2$perc_ref_rep_qual_f_low <- as.numeric(all_survey_results$perc_ref_rep_qual_f_low)
regression_dataset_2$perc_ref_rep_qual_avg <- as.numeric(all_survey_results$perc_ref_rep_qual_avg)
regression_dataset_2$perc_ref_rep_qual_f_high <- as.numeric(all_survey_results$perc_ref_rep_qual_f_high)
regression_dataset_2$perc_ref_rep_qual_v_high <- as.numeric(all_survey_results$perc_ref_rep_qual_v_high)
regression_dataset_2$ref_for_friends <-all_survey_results$ref_for_friends
regression_dataset_2$subs_binary <- as.numeric(all_survey_results$subs_binary)
regression_dataset_2$reps_binary <- as.numeric(all_survey_results$reps_binary)
regression_dataset_2$top_5_binary <- as.numeric(all_survey_results$top_5_binary)
regression_dataset_2$pos_binary <- as.numeric(all_survey_results$pos_binary)
regression_dataset_2$edit_binary <- as.numeric(all_survey_results$edit_binary)
regression_dataset_2$gen_binary <- as.numeric(all_survey_results$gen_binary)
regression_dataset_2$loc_binary <- as.numeric(all_survey_results$loc_binary)

regression_dataset <- left_join(regression_dataset,regression_dataset_2)

regression_dataset$low_qual_ref <- regression_dataset$perc_ref_rep_qual_v_low+regression_dataset$perc_ref_rep_qual_f_low
regression_dataset$high_qual_ref <- regression_dataset$perc_ref_rep_qual_f_high+regression_dataset$perc_ref_rep_qual_v_high

#### Outcomes on demographics

# Remove associate editor anonymity
reg_resp <- glm(`Remove associate editor anonymity` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Remove senior referee anonymity
reg_resp <- glm(`Remove senior referee anonymity`~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Disclose review history
reg_resp <- glm(`Disclose review history` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Open peer review
reg_resp <- glm(`Open peer review` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Share reports
reg_resp <- glm(`Share reports` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Formal appeal procedure
reg_resp <- glm(`Formal appeal procedure` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Double-blind peer review
reg_resp <- glm(`Double-blind peer review` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)

# Allow disqualifying referees
reg_resp <- glm(`Allow disqualifying referees` ~ subs_binary + reps_binary + pos_binary + gen_binary + edit_binary + loc_binary + top_5_binary, data = regression_dataset)
summary(reg_resp)




###########################################
### Ordered logit results (not reported in paper)
###########################################
# Remove associate editor anonymity
regression_dataset$`Remove associate editor anonymity - ordered` <- 
  ordered(regression_dataset$`Remove associate editor anonymity`, levels = c(1, 2, 3, 4, 5))
reg_resp <- polr(`Remove associate editor anonymity - ordered` ~ 
                   subs_binary + reps_binary + pos_binary + 
                   gen_binary + edit_binary + loc_binary + 
                   top_5_binary, 
                 data = regression_dataset, 
                 Hess = TRUE)
summary(reg_resp)
ct <- coef(summary(reg_resp))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)


# Remove senior referee anonymity
regression_dataset$`Remove senior referee anonymity - ordered` <- 
  ordered(regression_dataset$`Remove senior referee anonymity`, levels = c(1, 2, 3, 4, 5))

senior_ref_ident <- polr(`Remove senior referee anonymity - ordered` ~ 
                           subs_binary + reps_binary + pos_binary + 
                           gen_binary + edit_binary + loc_binary + 
                           top_5_binary, 
                         data = regression_dataset, 
                         Hess = TRUE)
summary(senior_ref_ident)
ct <- coef(summary(senior_ref_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)

# Disclose review history
regression_dataset$`Disclose review history - ordered` <- 
  ordered(regression_dataset$`Disclose review history`, levels = c(1, 2, 3, 4, 5))

review_hist_ident <- polr(`Disclose review history - ordered` ~ 
                            subs_binary + reps_binary + pos_binary + 
                            gen_binary + edit_binary + loc_binary + 
                            top_5_binary, 
                          data = regression_dataset, 
                          Hess = TRUE)
summary(review_hist_ident)
ct <- coef(summary(review_hist_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)

# Open peer review
regression_dataset$`Open peer review - ordered` <- 
  ordered(regression_dataset$`Open peer review`, levels = c(1, 2, 3, 4, 5))

open_peer_ident <- polr(`Open peer review - ordered` ~ 
                          subs_binary + reps_binary + pos_binary + 
                          gen_binary + edit_binary + loc_binary + 
                          top_5_binary, 
                        data = regression_dataset, 
                        Hess = TRUE)
summary(open_peer_ident)
ct <- coef(summary(open_peer_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)

# Share reports
regression_dataset$`Share reports - ordered` <- 
  ordered(regression_dataset$`Share reports`, levels = c(1, 2, 3, 4, 5))

share_rep_ident <- polr(`Share reports - ordered` ~ 
                          subs_binary + reps_binary + pos_binary + 
                          gen_binary + edit_binary + loc_binary + 
                          top_5_binary, 
                        data = regression_dataset, 
                        Hess = TRUE)
summary(share_rep_ident)
ct <- coef(summary(share_rep_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)

# Formal appeal procedure
regression_dataset$`Formal appeal procedure - ordered` <- 
  ordered(regression_dataset$`Formal appeal procedure`, levels = c(1, 2, 3, 4, 5))

appeal_proc_ident <- polr(`Formal appeal procedure - ordered` ~ 
                            subs_binary + reps_binary + pos_binary + 
                            gen_binary + edit_binary + loc_binary + 
                            top_5_binary, 
                          data = regression_dataset, 
                          Hess = TRUE)
summary(appeal_proc_ident)
ct <- coef(summary(appeal_proc_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)

# Double-blind peer review
regression_dataset$`Double-blind peer review - ordered` <- 
  ordered(regression_dataset$`Double-blind peer review`, levels = c(1, 2, 3, 4, 5))

dbl_blind_ident <- polr(`Double-blind peer review - ordered` ~ 
                          subs_binary + reps_binary + pos_binary + 
                          gen_binary + edit_binary + loc_binary + 
                          top_5_binary, 
                        data = regression_dataset, 
                        Hess = TRUE)
summary(dbl_blind_ident)
ct <- coef(summary(dbl_blind_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)

# Allow disqualifying referees
regression_dataset$`Allow disqualifying referees - ordered` <- 
  ordered(regression_dataset$`Allow disqualifying referees`, levels = c(1, 2, 3, 4, 5))

disqual_ref_ident <- polr(`Allow disqualifying referees - ordered` ~ 
                            subs_binary + reps_binary + pos_binary + 
                            gen_binary + edit_binary + loc_binary + 
                            top_5_binary, 
                          data = regression_dataset, 
                          Hess = TRUE)
summary(disqual_ref_ident)
ct <- coef(summary(disqual_ref_ident))
p <- pnorm(abs(ct[, "t value"]), lower.tail = FALSE) * 2
ct <- cbind(ct, "p value" = p)
print(ct)






