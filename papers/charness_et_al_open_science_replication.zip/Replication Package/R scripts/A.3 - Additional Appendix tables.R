##############################################################################
############################################################################## 
############# Analysis - Additional Appendix Tables ####
############################################################################## 
############################################################################## 

##### CHANGE THIS PATH #####
raw_path <- "YOUR PATH HERE"


#######################################
########## Setup ########## 
####################################### 
#### Load Libraries
library(rio)
library(tidyverse)
library(ggplot2)
library(plyr)
library(dplyr)
library(grid)
library(ggcorrplot)
library(jtools)
library(psych)
library(poLCA)
library(reshape2)
library(stringr)
library(ggtext)
library(tm)
library(wordcloud)
library(SnowballC)


### Set other paths 
path <- paste0(raw_path,"/Replication Package/")
inpath <- paste0(path,"/Cleaned Data/") 
inpath_comments <- paste0(path,"/Data about comments/")
outpath <- paste0(path,"/Figures/") 

### Helper functions
wrapper <- function(x, ...) 
{
  paste(strwrap(x, ...), collapse = "\n")
}

########## Data Setup ########## 

##### Main Data #####

### Load Main Data
all_survey_results <- import(paste(inpath,"all_survey_data.xlsx", sep=""))
all_survey_results$ID <- rownames(all_survey_results)

### Create Binned Location variable
all_survey_results$loc_bin[all_survey_results$location == "Afghanistan"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Argentina"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Australia"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Austria"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Bahrain"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Belgium"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Brazil"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Canada"] <- "United States/Canada"
all_survey_results$loc_bin[all_survey_results$location == "Chile"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "China"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Colombia"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Czech Republic"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Denmark"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Finland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "France"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Germany"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Greece"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Guatemala"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Hong Kong (S.A.R.)"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Hungary"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "India"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Iran, Islamic Republic of..."] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Ireland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Israel"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Italy"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Japan"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Liechtenstein"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Luxembourg"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Mexico"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Netherlands"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "New Zealand"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Norway"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Philippines"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Poland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Portugal"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Prefer not to say"] <- "Prefer not to say"
all_survey_results$loc_bin[all_survey_results$location == "Republic of Korea"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Russian Federation"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Saint Vincent and the Grenadines"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Serbia"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Singapore"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Slovakia"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "South Korea"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Spain"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Sweden"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Switzerland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "Thailand"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Turkey"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "United Arab Emirates"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "United Kingdom of Great Britain and Northern Ireland"] <- "Europe"
all_survey_results$loc_bin[all_survey_results$location == "United States of America"] <- "United States/Canada"
all_survey_results$loc_bin[all_survey_results$location == "Uruguay"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Uzbekistan"] <- "Asia/Oceania"
all_survey_results$loc_bin[all_survey_results$location == "Zimbabwe"] <- "Other"
all_survey_results$loc_bin[all_survey_results$location == "Prefer not to say"] <- "Prefer not to say"

all_survey_results$loc_bin[all_survey_results$loc_bin == "Other"] <- "Other countries"

### Create Binned Age variable
all_survey_results$age_reduced <- all_survey_results$age
all_survey_results$age_reduced[all_survey_results$age_reduced=="Under 30"] <- "Under 40"
all_survey_results$age_reduced[all_survey_results$age_reduced=="30-39"] <- "Under 40"
all_survey_results$age_reduced[all_survey_results$age_reduced=="60-69"] <- "60+"
all_survey_results$age_reduced[all_survey_results$age_reduced=="70+"] <- "60+"

### Create Binned Position variable
all_survey_results$pos_reduced <- all_survey_results$position
all_survey_results$pos_reduced[all_survey_results$pos_reduced=="PhD candidate"] <- "Postdoc/PhD"
all_survey_results$pos_reduced[all_survey_results$pos_reduced=="Post-doctoral researcher"] <- "Postdoc/PhD"

### Create Reports to Non-Econ and Econ Journals
all_survey_results$ref_repor_per_year <- as.numeric(all_survey_results$ref_repor_per_year)
all_survey_results$non_econ_rep_perc <- as.numeric(all_survey_results$perc_ref_rep_journals_4_other_discipline)
all_survey_results$non_econ_rep_perc <- all_survey_results$non_econ_rep_perc/100
all_survey_results$econ_rep_perc <- 1-all_survey_results$non_econ_rep_perc
all_survey_results$econ_reps <- all_survey_results$econ_rep_perc*all_survey_results$ref_repor_per_year

### Create total referee requests
all_survey_results$req_rej_num <- 0
all_survey_results$req_rej_num[!is.na(all_survey_results$rej_ref_req_num_times_with_0)] <- all_survey_results$rej_ref_req_num_times_with_0[!is.na(all_survey_results$rej_ref_req_num_times_with_0)]
all_survey_results$req_rej_num[!is.na(all_survey_results$rej_ref_req_num_times)] <- all_survey_results$rej_ref_req_num_times[!is.na(all_survey_results$rej_ref_req_num_times)]
all_survey_results$req_rej_num <- as.numeric(all_survey_results$req_rej_num)
all_survey_results$ref_repor_per_year <- as.numeric(all_survey_results$ref_repor_per_year)
all_survey_results$ref_req_tot <- NA
all_survey_results$ref_req_tot[!is.na(all_survey_results$req_rej_num)] <-  all_survey_results$req_rej_num[!is.na(all_survey_results$req_rej_num)]/2+all_survey_results$ref_repor_per_year[!is.na(all_survey_results$req_rej_num)]

### Create rejection rate
all_survey_results$reject_rate[!is.na(all_survey_results$ref_req_tot)] <- (all_survey_results$req_rej_num[!is.na(all_survey_results$ref_req_tot)]/(2*all_survey_results$ref_req_tot[!is.na(all_survey_results$ref_req_tot)]))*100

### Create referee request quartiles
all_survey_results$ref_req_tot_quart[!is.na(all_survey_results$ref_req_tot)] <- "Q1"
all_survey_results$ref_req_tot_quart[all_survey_results$ref_req_tot > 5.5] <- "Q2"
all_survey_results$ref_req_tot_quart[all_survey_results$ref_req_tot > 10] <- "Q3"
all_survey_results$ref_req_tot_quart[all_survey_results$ref_req_tot > 15.75] <- "Q4"

### Create referee reports quartiles
all_survey_results$ref_repor_quart[!is.na(all_survey_results$ref_repor_per_year)] <- "Q1"
all_survey_results$ref_repor_quart[all_survey_results$ref_repor_per_year > 4] <- "Q2"
all_survey_results$ref_repor_quart[all_survey_results$ref_repor_per_year > 8] <- "Q3"
all_survey_results$ref_repor_quart[all_survey_results$ref_repor_per_year > 12] <- "Q4"

## Make Number of Submissions numeric
all_survey_results$num_pap_sub <- as.numeric(all_survey_results$num_pap_sub)

##### Other Dataframes #####
### Fields Dataframe
fields2 <- as.data.frame(all_survey_results$research_areas)
colnames(fields2) <- "field"
fields2 <- as.data.frame(str_split_fixed(fields2$field, ",",n=13))
fields2$ID <- rownames(fields2)
fields_for_all <- fields2


### Demographics Subset Dataframe with binary variables
new_het_fig <- as.data.frame(all_survey_results$ID)
colnames(new_het_fig) <- "ID"
new_het_fig$pos <- all_survey_results$pos_reduced
new_het_fig$gender <- all_survey_results$gender
new_het_fig$edit <- all_survey_results$have_been_editor
new_het_fig$top_5 <- all_survey_results$perc_ref_rep_journals_1_top_5
new_het_fig$reps <- all_survey_results$ref_repor_per_year
new_het_fig$subs <- all_survey_results$num_pap_sub
new_het_fig$loc <- all_survey_results$loc_bin

new_het_fig$subs_binary <- 0
new_het_fig$subs_binary[new_het_fig$subs>6] <- 1
new_het_fig$reps_binary <- 0
new_het_fig$reps_binary[new_het_fig$reps>8] <- 1
new_het_fig$top_5_binary <- 0
new_het_fig$top_5_binary[new_het_fig$top_5>0] <- 1
new_het_fig$pos_binary <- 0
new_het_fig$pos_binary[new_het_fig$pos=="Postdoc/PhD"] <- 1
new_het_fig$pos_binary[new_het_fig$pos=="Assistant professor"] <- 1
new_het_fig$edit_binary <- 0
new_het_fig$edit_binary[new_het_fig$edit=="Yes"] <- 1
new_het_fig$gen_binary <- 0
new_het_fig$gen_binary[new_het_fig$gender=="Female"] <- 1
new_het_fig$loc_binary <- 0
new_het_fig$loc_binary[new_het_fig$loc=="United States/Canada"] <- 1

new_het_fig <- left_join(new_het_fig, fields_for_all, by="ID")
new_het_fig$field_binary <- 0
new_het_fig$field_binary[new_het_fig$V1=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V2=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V3=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V4=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V5=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V6=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V7=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V8=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V9=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V10=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V11=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V12=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V13=="Behavioral economics"] <- 1
new_het_fig$field_binary[new_het_fig$V1=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V2=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V3=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V4=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V5=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V6=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V7=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V8=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V9=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V10=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V11=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V12=="Experimental economics"] <- 1
new_het_fig$field_binary[new_het_fig$V13=="Experimental economics"] <- 1
new_het_fig <- new_het_fig[,-c(16:28)]



###########################################
###########################################
##### Appendix A Tables and Stats
###########################################
###########################################

###########################################
### Table A.2
###########################################

survey_stats_table <- new_het_fig
survey_stats_table$age <- all_survey_results$age_reduced
survey_stats_table$survey_completion <- as.numeric(all_survey_results$Progress)
survey_stats_table$pub <- all_survey_results$num_papers_pub
survey_stats_table$survey <- all_survey_results$survey_num
survey_stats_table <- survey_stats_table[survey_stats_table$survey_completion>4,]
survey_stats_table$survey[survey_stats_table$survey=="Survey EEA1"] <- "Survey EEA"
survey_stats_table$survey[survey_stats_table$survey=="Survey EEA2"] <- "Survey EEA"

survey_stats_table_count <- count(survey_stats_table$survey)
colnames(survey_stats_table_count) <- c("survey","n")

survey_stats_table_count_gender <- count(survey_stats_table[!is.na(survey_stats_table$gender),], c("survey","gender"))
survey_stats_table_count_gender <- survey_stats_table_count_gender[!(survey_stats_table_count_gender$gender == "Prefer not to say"),]

survey_stats_table_count_age <- count(survey_stats_table[!is.na(survey_stats_table$age),], c("survey","age"))
survey_stats_table_count_age <- survey_stats_table_count_age[!(survey_stats_table_count_age$age == "Prefer not to say"),]

survey_stats_table_count_pos <- count(survey_stats_table[!is.na(survey_stats_table$pos),], c("survey","pos"))
survey_stats_table_count_pos <- survey_stats_table_count_pos[!(survey_stats_table_count_pos$pos == "Prefer not to say"),]

survey_stats_table_count_loc <- count(survey_stats_table[!is.na(survey_stats_table$loc),], c("survey","loc"))
survey_stats_table_count_loc <- survey_stats_table_count_loc[!(survey_stats_table_count_loc$loc == "Prefer not to say"),]

survey_stats_table_count_edit <- count(survey_stats_table[!is.na(survey_stats_table$edit),], c("survey","edit"))
survey_stats_table_count_edit <- survey_stats_table_count_edit[!(survey_stats_table_count_edit$edit == "Prefer not to say"),]

survey_stats_table_count_top_5 <- count(survey_stats_table[!is.na(survey_stats_table$top_5),], c("survey","top_5_binary"))

survey_stats_table$pub <- as.character(survey_stats_table$pub)
survey_stats_table$pub <- as.numeric(survey_stats_table$pub)
survey_stats_table_pub_means <- aggregate(survey_stats_table$pub[!is.na(survey_stats_table$pub)], list(survey_stats_table$survey[!is.na(survey_stats_table$pub)]), mean)


survey_stats_table_count_gender <- survey_stats_table_count_gender %>%
  dplyr::group_by(survey) %>%
  dplyr::mutate(n = sum(freq, na.rm = TRUE)) %>%
  dplyr::ungroup()
survey_stats_table_count_gender$perc <- survey_stats_table_count_gender$freq/survey_stats_table_count_gender$n
survey_stats_table_count_gender

survey_stats_table_count_age <- survey_stats_table_count_age %>%
  dplyr::group_by(survey) %>%
  dplyr::mutate(n = sum(freq, na.rm = TRUE)) %>%
  dplyr::ungroup()
survey_stats_table_count_age <- left_join(survey_stats_table_count_age, survey_stats_table_count) 
survey_stats_table_count_age$perc <- survey_stats_table_count_age$freq/survey_stats_table_count_age$n
survey_stats_table_count_age

survey_stats_table_count_loc <- survey_stats_table_count_loc %>%
  dplyr::group_by(survey) %>%
  dplyr::mutate(n = sum(freq, na.rm = TRUE)) %>%
  dplyr::ungroup()
survey_stats_table_count_loc <- left_join(survey_stats_table_count_loc, survey_stats_table_count) 
survey_stats_table_count_loc$perc <- survey_stats_table_count_loc$freq/survey_stats_table_count_loc$n
survey_stats_table_count_loc

survey_stats_table_count_pos <- survey_stats_table_count_pos %>%
  dplyr::group_by(survey) %>%
  dplyr::mutate(n = sum(freq, na.rm = TRUE)) %>%
  dplyr::ungroup()
survey_stats_table_count_pos <- left_join(survey_stats_table_count_pos, survey_stats_table_count) 
survey_stats_table_count_pos$perc <- survey_stats_table_count_pos$freq/survey_stats_table_count_pos$n
survey_stats_table_count_pos

survey_stats_table_count_edit <- survey_stats_table_count_edit %>%
  dplyr::group_by(survey) %>%
  dplyr::mutate(n = sum(freq, na.rm = TRUE)) %>%
  dplyr::ungroup()
survey_stats_table_count_edit <- left_join(survey_stats_table_count_edit, survey_stats_table_count) 
survey_stats_table_count_edit$perc <- survey_stats_table_count_edit$freq/survey_stats_table_count_edit$n
survey_stats_table_count_edit

survey_stats_table_pub_means

survey_stats_table_count_top_5 <- survey_stats_table_count_top_5 %>%
  dplyr::group_by(survey) %>%
  dplyr::mutate(n = sum(freq, na.rm = TRUE)) %>%
  dplyr::ungroup()
survey_stats_table_count_top_5 <- left_join(survey_stats_table_count_top_5, survey_stats_table_count) 
survey_stats_table_count_top_5$perc <- survey_stats_table_count_top_5$freq/survey_stats_table_count_top_5$n
survey_stats_table_count_top_5


###########################################
### Table A.3
###########################################

het_stats <- new_het_fig[new_het_fig$field_binary==1,]
het_stats <- het_stats[!is.na(het_stats$pos),]
# 802 obs
het_stats_gen <- count(het_stats$gen_binary)
het_stats_gen$cat <- "Female"
het_stats_pos <- count(het_stats$pos_binary)
het_stats_pos$cat <- "Junior"
het_stats_edit <- count(het_stats$edit_binary)
het_stats_edit$cat <- "Editor"
het_stats_field <- count(het_stats$field_binary)
het_stats_field$cat <- "Behav/Exp"
het_stats_loc <- count(het_stats$loc_binary)
het_stats_loc$cat <- "US/Canada"
het_stats_top_5 <- count(het_stats$top_5_binary)
het_stats_top_5$cat <- "Top 5 reviewer"
het_stats_reps <- count(het_stats$reps_binary)
het_stats_reps$cat <- "Active reviewer"
het_stats_subs <- count(het_stats$subs_binary)
het_stats_subs$cat <- "Active author"
het_stats_all <- c(1, nrow(het_stats), "All")

het_stats_gen_main <- rbind(het_stats_field, het_stats_gen, het_stats_pos, 
                            het_stats_loc, het_stats_edit, het_stats_top_5,
                            het_stats_reps, het_stats_subs, het_stats_all)

het_stats_gen_main <- het_stats_gen_main[!(het_stats_gen_main$x==0),]
het_stats_gen_main$freq <- as.numeric(het_stats_gen_main$freq)
het_stats_gen_main$perc <- round(het_stats_gen_main$freq/802*100, digits=1)

het_stats_gen_main <- het_stats_gen_main[,c(3,2,4)]
colnames(het_stats_gen_main) <- c("Variable", "N", "Percent")





###########################################
### Table A.5
###########################################
## Variables for demographics comparison table
dems_discussion <- new_het_fig
dems_discussion$age <- all_survey_results$age_reduced
dems_discussion <- dems_discussion[!is.na(dems_discussion$gender),]

#publications
dems_pub <- as.data.frame(all_survey_results$num_papers_pub)
colnames(dems_pub) <- "pubs"
dems_pub$gender <- all_survey_results$gender
dems_pub <- dems_pub[!is.na(dems_pub$gender),]
dems_pub$pubs <- as.character(dems_pub$pubs)
dems_pub$pubs <- as.numeric(dems_pub$pubs)
dems_pub$pubs[dems_pub$pubs>200] <- 200


### fields ###
fields_for_all_2 <- fields_for_all[!fields_for_all$V1=="",]
fields_n <- nrow(fields_for_all_2)
fields_for_all_2$macro <- 0
fields_for_all_2$macro[fields_for_all_2$V1=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V1=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V1=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V2=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V2=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V2=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V3=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V3=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V3=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V4=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V4=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V4=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V5=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V5=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V5=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V6=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V6=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V6=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V7=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V7=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V7=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V8=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V8=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V8=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V9=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V9=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V9=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V10=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V10=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V10=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V11=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V11=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V11=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V12=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V12=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V12=="Financial economics"]<- 1

fields_for_all_2$macro[fields_for_all_2$V13=="Macroeconomics"]<- 1
fields_for_all_2$macro[fields_for_all_2$V13=="International trade"]<- 1
fields_for_all_2$macro[fields_for_all_2$V13=="Financial economics"]<- 1

fields_for_all_2$micro <- 0
fields_for_all_2$micro[fields_for_all_2$V1=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V2=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V3=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V4=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V5=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V6=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V7=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V8=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V9=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V10=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V11=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V12=="Applied microeconomics"]<- 1
fields_for_all_2$micro[fields_for_all_2$V13=="Applied microeconomics"]<- 1

fields_for_all_2$micro[fields_for_all_2$V1=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V2=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V3=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V4=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V5=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V6=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V7=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V8=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V9=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V10=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V11=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V12=="Microeconomic theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V13=="Microeconomic theory"]<- 1

fields_for_all_2$micro[fields_for_all_2$V1=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V2=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V3=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V4=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V5=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V6=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V7=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V8=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V9=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V10=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V11=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V12=="Decision theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V13=="Decision theory"]<- 1

fields_for_all_2$micro[fields_for_all_2$V1=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V2=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V3=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V4=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V5=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V6=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V7=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V8=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V9=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V10=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V11=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V12=="Game theory"]<- 1
fields_for_all_2$micro[fields_for_all_2$V13=="Game theory"]<- 1



fields_for_all_2$metrics <- 0
fields_for_all_2$metrics[fields_for_all_2$V1=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V2=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V3=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V4=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V5=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V6=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V7=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V8=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V9=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V10=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V11=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V12=="Applied econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V13=="Applied econometrics"]<- 1

fields_for_all_2$metrics[fields_for_all_2$V1=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V2=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V3=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V4=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V5=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V6=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V7=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V8=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V9=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V10=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V11=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V12=="Econometric theory"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V13=="Econometric theory"]<- 1


fields_for_all_2$metrics[fields_for_all_2$V1=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V2=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V3=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V4=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V5=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V6=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V7=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V8=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V9=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V10=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V11=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V12=="Structural econometrics"]<- 1
fields_for_all_2$metrics[fields_for_all_2$V13=="Structural econometrics"]<- 1


fields_for_all_2$develop <- 0
fields_for_all_2$develop[fields_for_all_2$V1=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V2=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V3=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V4=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V5=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V6=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V7=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V8=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V9=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V10=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V11=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V12=="Development economics"]<- 1
fields_for_all_2$develop[fields_for_all_2$V13=="Development economics"]<- 1

fields_for_all_2$other <- 0
fields_for_all_2$other[fields_for_all_2$V1=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V2=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V3=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V4=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V5=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V6=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V7=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V8=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V9=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V10=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V11=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V12=="Economic history"]<- 1
fields_for_all_2$other[fields_for_all_2$V13=="Economic history"]<- 1


fields_for_all_2$other[fields_for_all_2$V1=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V2=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V3=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V4=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V5=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V6=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V7=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V8=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V9=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V10=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V11=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V12=="Political economy"]<- 1
fields_for_all_2$other[fields_for_all_2$V13=="Political economy"]<- 1

fields_for_all_2$other[fields_for_all_2$V1=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V2=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V3=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V4=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V5=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V6=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V7=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V8=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V9=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V10=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V11=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V12=="Urban economics"]<- 1
fields_for_all_2$other[fields_for_all_2$V13=="Urban economics"]<- 1


fields_for_all_2$other[fields_for_all_2$V1=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V2=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V3=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V4=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V5=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V6=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V7=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V8=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V9=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V10=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V11=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V12=="Other - indicate:"]<- 1
fields_for_all_2$other[fields_for_all_2$V13=="Other - indicate:"]<- 1

fields_for_all_2$io <- 0
fields_for_all_2$io[fields_for_all_2$V1=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V2=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V3=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V4=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V5=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V6=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V7=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V8=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V9=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V10=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V11=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V12=="Industrial organization"]<- 1
fields_for_all_2$io[fields_for_all_2$V13=="Industrial organization"]<- 1


fields_for_all_2$labor <- 0
fields_for_all_2$labor[fields_for_all_2$V1=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V2=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V3=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V4=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V5=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V6=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V7=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V8=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V9=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V10=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V11=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V12=="Labor economics"]<- 1
fields_for_all_2$labor[fields_for_all_2$V13=="Labor economics"]<- 1


fields_for_all_2$public <- 0
fields_for_all_2$public[fields_for_all_2$V1=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V2=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V3=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V4=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V5=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V6=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V7=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V8=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V9=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V10=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V11=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V12=="Public economics"]<- 1
fields_for_all_2$public[fields_for_all_2$V13=="Public economics"]<- 1

fields_for_all_2$behvioral <- 0
fields_for_all_2$behvioral[fields_for_all_2$V1=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V2=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V3=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V4=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V5=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V6=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V7=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V8=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V9=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V10=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V11=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V12=="Behavioral economics"]<- 1
fields_for_all_2$behvioral[fields_for_all_2$V13=="Behavioral economics"]<- 1

fields_for_all_2$experimental <- 0
fields_for_all_2$experimental[fields_for_all_2$V1=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V2=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V3=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V4=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V5=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V6=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V7=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V8=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V9=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V10=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V11=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V12=="Experimental economics"]<- 1
fields_for_all_2$experimental[fields_for_all_2$V13=="Experimental economics"]<- 1

fields_for_all_2$sum <- rowSums(fields_for_all_2[,15:22])
fields_for_all_2$sum2 <- rowSums(fields_for_all_2[,15:24])
sum(fields_for_all_2$sum2)

n_fields <- sum(fields_for_all_2$sum)


#### Table output
## Total is 1459
gen_count <- count(dems_discussion$gender[!is.na(dems_discussion$gender)])
n <-nrow(dems_discussion)
gen_count$perc <- gen_count$freq/n
gen_count
# Age total is 1459 - 78 (prefer not to say) = 1381
age_counts <- count(dems_discussion$age[!is.na(dems_discussion$age)])
n_age <- nrow(dems_discussion[dems_discussion$age != "Prefer not to say",])
age_counts$perc <- age_counts$freq/n_age
age_counts
# Location total is 1459 - 67 (prefer not to say) = 1392
loc_counts <- count(dems_discussion$loc[!is.na(dems_discussion$loc)])
n_loc <- nrow(dems_discussion[dems_discussion$loc != "Prefer not to say",])
loc_counts$perc <- loc_counts$freq/n_loc
loc_counts

# Field counts
sum(fields_for_all_2$micro)/n_fields
sum(fields_for_all_2$macro)/n_fields
sum(fields_for_all_2$metrics)/n_fields
sum(fields_for_all_2$develop)/n_fields
sum(fields_for_all_2$labor)/n_fields
sum(fields_for_all_2$io)/n_fields
sum(fields_for_all_2$public)/n_fields
sum(fields_for_all_2$other)/n_fields

# Position total is 1459 - 58 (prefer not to say) = 1401
pos_counts <- count(dems_discussion$pos[!is.na(dems_discussion$pos)])
n_pos <- nrow(dems_discussion[dems_discussion$pos != "Prefer not to say",])
pos_counts$perc <- pos_counts$freq/n_pos
pos_counts


mean(dems_pub$pubs)




###########################################
### Table A.4
###########################################
dems_discussion_behav <- dems_discussion[dems_discussion$field_binary==1,]


gen_count <- count(dems_discussion_behav$gender[!is.na(dems_discussion_behav$gender)])
n <-nrow(dems_discussion_behav)
gen_count$perc <- gen_count$freq/n
gen_count


pos_counts <- count(dems_discussion_behav$pos[!is.na(dems_discussion_behav$pos)])
n_pos <- nrow(dems_discussion_behav[dems_discussion_behav$pos != "Prefer not to say",])
pos_counts$perc <- pos_counts$freq/n_pos
pos_counts


loc_counts <- count(dems_discussion_behav$loc[!is.na(dems_discussion_behav$loc)])
n_loc <- nrow(dems_discussion_behav[dems_discussion_behav$loc != "Prefer not to say",])
loc_counts$perc <- loc_counts$freq/n_loc
loc_counts


