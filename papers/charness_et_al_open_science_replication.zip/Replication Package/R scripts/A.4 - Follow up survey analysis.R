##############################################################################
############################################################################## 
############# Follow-up Survey Analysis ####
############################################################################## 
##############################################################################


##### CHANGE THIS PATH #####
raw_path <- "YOUR PATH HERE"


#######################################
########## Setup ########## 
####################################### 
library(rio)
library(tidyverse)
library(dplyr) 
library(plyr)

### Set other paths 
path <- paste0(raw_path,"/Replication Package/")

#### Data Cleaning ####
followup_data <- import(paste0(path, "/Peer Review Survey Reponses/Followup Survey/follow_up_survey.csv"))
colnames(followup_data) <- followup_data[1,]
followup_data <- followup_data[-c(1:2,24),-c(1:10)]
colnames(followup_data)[3] <- "activity_in_dist"

total_n <- nrow(followup_data)
total_n

#### Position (N=116 without "prefer not to say")####
followup_data$position_reduced <- followup_data$position
followup_data$position_reduced[followup_data$position=="PhD candidate"] <- "Postdoc/PhD"
followup_data$position_reduced[followup_data$position=="Post-doctoral researcher"] <- "Postdoc/PhD"
followup_data$position_reduced[followup_data$position=="Associate professor (tenured)"] <- "Associate professor"
followup_data$position_reduced[followup_data$position=="Associate professor (untenured)"] <- "Associate professor"

position_stats <- count(followup_data$position_reduced)
position_stats$perc <- position_stats$freq/(total_n-1)
position_stats


#### Current editors (N=117)####
followup_data$editor_binary <- 1
followup_data$editor_binary[followup_data$current_editorial_positions =="Not an editorial board member anywhere"] <- 0

current_editor_perc <- sum(followup_data$editor_binary)/total_n
current_editor_perc

#### desk rejections (N=114)####
followup_data$submissions_made <- as.numeric(followup_data$submissions_made)
followup_data$desk_rejections <- as.numeric(followup_data$desk_rejections)
followup_data$desk_rej_perc <- followup_data$desk_rejections/followup_data$submissions_made 
desk_rej_perc <- as.data.frame(followup_data$desk_rej_perc)
colnames(desk_rej_perc) <- c("desk_rej_perc")
desk_rej_perc <- as.data.frame(desk_rej_perc[!is.na(desk_rej_perc$desk_rej_perc),])
colnames(desk_rej_perc) <- c("desk_rej_perc")
desk_rej_perc <- as.data.frame(desk_rej_perc[!(desk_rej_perc$desk_rej_perc==Inf),])
colnames(desk_rej_perc) <- c("desk_rej_perc")
mean(desk_rej_perc$desk_rej_perc)
median(desk_rej_perc$desk_rej_perc)
