##############################################################################
############################################################################## 
############# Data Cleaning - Survey Data Cleaning ##############
############################################################################## 
############################################################################## 


##### CHANGE THIS PATH #####
raw_path <- "YOUR PATH HERE"


#######################################
########## Setup ########## 
####################################### 
library(rio)
library(tidyverse)
library(ggplot2)
library(stargazer)
library(openxlsx)
library(expss)
library(plyr)
library(dplyr)

### Set other paths 
path <- paste0(raw_path,"/Replication Package/")


#Import Data
pilot_survey <- import(paste0(path,"Peer Review Survey Reponses/Pilot Survey - January 3, 2021.csv"))
ESA_data <- import(paste0(path,"Peer Review Survey Reponses/ESA - January 3, 2021.csv"))
EEA1_data <- import(paste0(path,"Peer Review Survey Reponses/EEA Survey 1 - January 3, 2021.csv"))
MM1_data <- import(paste0(path,"Peer Review Survey Reponses/Mail merge 1 - January 3, 2021.csv"))
DT_data <- import(paste0(path,"Peer Review Survey Reponses/DT Survey - January 8, 2021.csv"))
EEA2_data <- import(paste0(path,"Peer Review Survey Reponses/EEA Survey 2 - January 8, 2021.csv"))
CESifo_data <- import(paste0(path,"Peer Review Survey Reponses/CESifo survey - January 8, 2021.csv"))
CEPR_data <- import(paste0(path,"Peer Review Survey Reponses/CEPR survey - January 8, 2021.csv"))
MM2_data <- import(paste0(path,"Peer Review Survey Reponses/Mail merge 2 - February 20, 2021.csv"))
outpath <- paste0(path,"/Cleaned Data/")


#Clean datasets
#Remove unnecessary columns and rows
pilot_survey <- pilot_survey[-c(1,2),-c(1,2,3,7,8,9,10)]
ESA_data <- ESA_data[-c(1,2),-c(1,2,3,7,8,9,10)]
EEA1_data <- EEA1_data[-c(1,2),-c(1,2,3,7,8,9,10)]
MM1_data <- MM1_data[-c(1,2),-c(1,2,3,7,8,9,10)]
DT_data <- DT_data[-c(1,2),-c(1,2,3,7,8,9,10)]
EEA2_data <- EEA2_data[-c(1,2),-c(1,2,3,7,8,9,10)]
CESifo_data <- CESifo_data[-c(1,2),-c(1,2,3,7,8,9,10)]
CEPR_data <- CEPR_data[-c(1,2),-c(1,2,3,7,8,9,10)]
MM2_data <- MM2_data[-c(1,2),-c(1,2,3,7,8,9,10)]


#Rename columns so all datasets match
pilot_survey <- pilot_survey %>% dplyr::rename(Q4_1A=Q4_1, Q4_2A=Q4_2, Q4_3A=Q4_3, Q4_4A=Q4_4, Q4_5A=Q4_5, Q4_6A=Q4_6, Q4_7A=Q4_7)
pilot_survey <- pilot_survey %>% dplyr::rename(Q2_1.A=Q2_1.1, Q2_2.A=Q2_2.1, Q2_3.A=Q2_3.1, Q2_4.A=Q2_4.1, Q2_5.A=Q2_5.1, Q2_6.A=Q2_6, Q2_7.A=Q2_7, Q2_8.A=Q2_8)
pilot_survey <- pilot_survey %>% dplyr::rename(Q1.A=Q1.2, Q2.1=Q2, Q1.2=Q1.3, Q2_1.1=Q2_1.2,Q2_2.1=Q2_2.2, Q2_3.1=Q2_3.2, Q2_4.1=Q2_4.2, Q5.A=Q5.2, Q6_1.A=Q6_1.1)
pilot_survey <- pilot_survey %>% dplyr::rename(Q47A=Q47, Q48A=Q48, Q1.3=Q1.4, Q5.2=Q5.3, Q9.A=Q9.1, Q11A=Q11, Q47A=Q47, Q48A=Q48)

#Add missing columns so all datasets match
#Survey Pilot
pilot_survey$Q2 <- NA
pilot_survey$Q2 <- as.character(pilot_survey$Q2)
pilot_survey$Q9.1 <- NA
pilot_survey$Q9.1 <- as.character(pilot_survey$Q9.1)
pilot_survey$Q11 <- NA
pilot_survey$Q11 <- as.character(pilot_survey$Q11)
pilot_survey$Q58.1 <- NA
pilot_survey$Q58.1 <- as.character(pilot_survey$Q58.1)
pilot_survey$survey_num <- "Survey Pilot"
pilot_survey$Q59 <- NA
pilot_survey$Q59 <- as.character(pilot_survey$Q59)
pilot_survey$Q60 <- NA
pilot_survey$Q60 <- as.character(pilot_survey$Q60)

#Survey ESA
ESA_data$Q4_1A <- NA
ESA_data$Q4_1A <- as.character(ESA_data$Q4_1A)
ESA_data$Q4_2A <- NA
ESA_data$Q4_2A <- as.character(ESA_data$Q4_2A)
ESA_data$Q4_3A <- NA
ESA_data$Q4_3A <- as.character(ESA_data$Q4_3A)
ESA_data$Q4_4A <- NA
ESA_data$Q4_4A <- as.character(ESA_data$Q4_4A)
ESA_data$Q4_5A <- NA
ESA_data$Q4_5A <- as.character(ESA_data$Q4_5A)
ESA_data$Q4_6A <- NA
ESA_data$Q4_6A <- as.character(ESA_data$Q4_6A)
ESA_data$Q4_7A <- NA
ESA_data$Q4_7A <- as.character(ESA_data$Q4_7A)
ESA_data$Q2_1.A <- NA
ESA_data$Q2_1.A <- as.character(ESA_data$Q2_1.A)
ESA_data$Q2_2.A <- NA
ESA_data$Q2_2.A <- as.character(ESA_data$Q2_2.A)
ESA_data$Q2_3.A <- NA
ESA_data$Q2_3.A <- as.character(ESA_data$Q2_3.A)
ESA_data$Q2_4.A <- NA
ESA_data$Q2_4.A <- as.character(ESA_data$Q2_4.A)
ESA_data$Q2_5.A <- NA
ESA_data$Q2_5.A <- as.character(ESA_data$Q2_5.A)
ESA_data$Q2_6.A <- NA
ESA_data$Q2_6.A <- as.character(ESA_data$Q2_6.A)
ESA_data$Q2_7.A <- NA
ESA_data$Q2_7.A <- as.character(ESA_data$Q2_7.A)
ESA_data$Q2_8.A <- NA
ESA_data$Q2_8.A <- as.character(ESA_data$Q2_8.A)
ESA_data$Q1.A <- NA
ESA_data$Q1.A <- as.character(ESA_data$Q1.A)
ESA_data$Q5.A <- NA
ESA_data$Q5.A <- as.character(ESA_data$Q5.A)
ESA_data$Q6_1.A <- NA
ESA_data$Q6_1.A <- as.character(ESA_data$Q6_1.A)
ESA_data$Q9.A <- NA
ESA_data$Q9.A <- as.character(ESA_data$Q9.A)
ESA_data$Q11A <- NA
ESA_data$Q11A <- as.character(ESA_data$Q11A)
ESA_data$Q47A <- NA
ESA_data$Q47A <- as.character(ESA_data$Q47A)
ESA_data$Q48A <- NA
ESA_data$Q48A <- as.character(ESA_data$Q48A)
ESA_data$Q58.1 <- NA
ESA_data$Q58.1 <- as.character(ESA_data$Q58.1)
ESA_data$survey_num <- "Survey ESA"
ESA_data$Q59 <- NA
ESA_data$Q59 <- as.character(ESA_data$Q59)
ESA_data$Q60 <- NA
ESA_data$Q60 <- as.character(ESA_data$Q60)

#Survey EEA1
EEA1_data$Q4_1A <- NA
EEA1_data$Q4_1A <- as.character(EEA1_data$Q4_1A)
EEA1_data$Q4_2A <- NA
EEA1_data$Q4_2A <- as.character(EEA1_data$Q4_2A)
EEA1_data$Q4_3A <- NA
EEA1_data$Q4_3A <- as.character(EEA1_data$Q4_3A)
EEA1_data$Q4_4A <- NA
EEA1_data$Q4_4A <- as.character(EEA1_data$Q4_4A)
EEA1_data$Q4_5A <- NA
EEA1_data$Q4_5A <- as.character(EEA1_data$Q4_5A)
EEA1_data$Q4_6A <- NA
EEA1_data$Q4_6A <- as.character(EEA1_data$Q4_6A)
EEA1_data$Q4_7A <- NA
EEA1_data$Q4_7A <- as.character(EEA1_data$Q4_7A)
EEA1_data$Q2_1.A <- NA
EEA1_data$Q2_1.A <- as.character(EEA1_data$Q2_1.A)
EEA1_data$Q2_2.A <- NA
EEA1_data$Q2_2.A <- as.character(EEA1_data$Q2_2.A)
EEA1_data$Q2_3.A <- NA
EEA1_data$Q2_3.A <- as.character(EEA1_data$Q2_3.A)
EEA1_data$Q2_4.A <- NA
EEA1_data$Q2_4.A <- as.character(EEA1_data$Q2_4.A)
EEA1_data$Q2_5.A <- NA
EEA1_data$Q2_5.A <- as.character(EEA1_data$Q2_5.A)
EEA1_data$Q2_6.A <- NA
EEA1_data$Q2_6.A <- as.character(EEA1_data$Q2_6.A)
EEA1_data$Q2_7.A <- NA
EEA1_data$Q2_7.A <- as.character(EEA1_data$Q2_7.A)
EEA1_data$Q2_8.A <- NA
EEA1_data$Q2_8.A <- as.character(EEA1_data$Q2_8.A)
EEA1_data$Q1.A <- NA
EEA1_data$Q1.A <- as.character(EEA1_data$Q1.A)
EEA1_data$Q5.A <- NA
EEA1_data$Q5.A <- as.character(EEA1_data$Q5.A)
EEA1_data$Q6_1.A <- NA
EEA1_data$Q6_1.A <- as.character(EEA1_data$Q6_1.A)
EEA1_data$Q9.A <- NA
EEA1_data$Q9.A <- as.character(EEA1_data$Q9.A)
EEA1_data$Q11A <- NA
EEA1_data$Q11A <- as.character(EEA1_data$Q11A)
EEA1_data$Q47A <- NA
EEA1_data$Q47A <- as.character(EEA1_data$Q47A)
EEA1_data$Q48A <- NA
EEA1_data$Q48A <- as.character(EEA1_data$Q48A)
EEA1_data$Q58.1 <- NA
EEA1_data$Q58.1 <- as.character(EEA1_data$Q58.1)
EEA1_data$survey_num <- "Survey EEA1"
EEA1_data$Q59 <- NA
EEA1_data$Q59 <- as.character(EEA1_data$Q59)
EEA1_data$Q60 <- NA
EEA1_data$Q60 <- as.character(EEA1_data$Q60)

#Survey MM1
MM1_data$Q4_1A <- NA
MM1_data$Q4_1A <- as.character(MM1_data$Q4_1A)
MM1_data$Q4_2A <- NA
MM1_data$Q4_2A <- as.character(MM1_data$Q4_2A)
MM1_data$Q4_3A <- NA
MM1_data$Q4_3A <- as.character(MM1_data$Q4_3A)
MM1_data$Q4_4A <- NA
MM1_data$Q4_4A <- as.character(MM1_data$Q4_4A)
MM1_data$Q4_5A <- NA
MM1_data$Q4_5A <- as.character(MM1_data$Q4_5A)
MM1_data$Q4_6A <- NA
MM1_data$Q4_6A <- as.character(MM1_data$Q4_6A)
MM1_data$Q4_7A <- NA
MM1_data$Q4_7A <- as.character(MM1_data$Q4_7A)
MM1_data$Q2_1.A <- NA
MM1_data$Q2_1.A <- as.character(MM1_data$Q2_1.A)
MM1_data$Q2_2.A <- NA
MM1_data$Q2_2.A <- as.character(MM1_data$Q2_2.A)
MM1_data$Q2_3.A <- NA
MM1_data$Q2_3.A <- as.character(MM1_data$Q2_3.A)
MM1_data$Q2_4.A <- NA
MM1_data$Q2_4.A <- as.character(MM1_data$Q2_4.A)
MM1_data$Q2_5.A <- NA
MM1_data$Q2_5.A <- as.character(MM1_data$Q2_5.A)
MM1_data$Q2_6.A <- NA
MM1_data$Q2_6.A <- as.character(MM1_data$Q2_6.A)
MM1_data$Q2_7.A <- NA
MM1_data$Q2_7.A <- as.character(MM1_data$Q2_7.A)
MM1_data$Q2_8.A <- NA
MM1_data$Q2_8.A <- as.character(MM1_data$Q2_8.A)
MM1_data$Q1.A <- NA
MM1_data$Q1.A <- as.character(MM1_data$Q1.A)
MM1_data$Q5.A <- NA
MM1_data$Q5.A <- as.character(MM1_data$Q5.A)
MM1_data$Q6_1.A <- NA
MM1_data$Q6_1.A <- as.character(MM1_data$Q6_1.A)
MM1_data$Q9.A <- NA
MM1_data$Q9.A <- as.character(MM1_data$Q9.A)
MM1_data$Q11A <- NA
MM1_data$Q11A <- as.character(MM1_data$Q11A)
MM1_data$Q47A <- NA
MM1_data$Q47A <- as.character(MM1_data$Q47A)
MM1_data$Q48A <- NA
MM1_data$Q48A <- as.character(MM1_data$Q48A)
MM1_data$survey_num <- "Survey MM1"
MM1_data$Q59 <- NA
MM1_data$Q59 <- as.character(MM1_data$Q59)
MM1_data$Q60 <- NA
MM1_data$Q60 <- as.character(MM1_data$Q60)

#Survey DT
DT_data$Q4_1A <- NA
DT_data$Q4_1A <- as.character(DT_data$Q4_1A)
DT_data$Q4_2A <- NA
DT_data$Q4_2A <- as.character(DT_data$Q4_2A)
DT_data$Q4_3A <- NA
DT_data$Q4_3A <- as.character(DT_data$Q4_3A)
DT_data$Q4_4A <- NA
DT_data$Q4_4A <- as.character(DT_data$Q4_4A)
DT_data$Q4_5A <- NA
DT_data$Q4_5A <- as.character(DT_data$Q4_5A)
DT_data$Q4_6A <- NA
DT_data$Q4_6A <- as.character(DT_data$Q4_6A)
DT_data$Q4_7A <- NA
DT_data$Q4_7A <- as.character(DT_data$Q4_7A)
DT_data$Q2_1.A <- NA
DT_data$Q2_1.A <- as.character(DT_data$Q2_1.A)
DT_data$Q2_2.A <- NA
DT_data$Q2_2.A <- as.character(DT_data$Q2_2.A)
DT_data$Q2_3.A <- NA
DT_data$Q2_3.A <- as.character(DT_data$Q2_3.A)
DT_data$Q2_4.A <- NA
DT_data$Q2_4.A <- as.character(DT_data$Q2_4.A)
DT_data$Q2_5.A <- NA
DT_data$Q2_5.A <- as.character(DT_data$Q2_5.A)
DT_data$Q2_6.A <- NA
DT_data$Q2_6.A <- as.character(DT_data$Q2_6.A)
DT_data$Q2_7.A <- NA
DT_data$Q2_7.A <- as.character(DT_data$Q2_7.A)
DT_data$Q2_8.A <- NA
DT_data$Q2_8.A <- as.character(DT_data$Q2_8.A)
DT_data$Q1.A <- NA
DT_data$Q1.A <- as.character(DT_data$Q1.A)
DT_data$Q5.A <- NA
DT_data$Q5.A <- as.character(DT_data$Q5.A)
DT_data$Q6_1.A <- NA
DT_data$Q6_1.A <- as.character(DT_data$Q6_1.A)
DT_data$Q9.A <- NA
DT_data$Q9.A <- as.character(DT_data$Q9.A)
DT_data$Q11A <- NA
DT_data$Q11A <- as.character(DT_data$Q11A)
DT_data$Q47A <- NA
DT_data$Q47A <- as.character(DT_data$Q47A)
DT_data$Q48A <- NA
DT_data$Q48A <- as.character(DT_data$Q48A)
DT_data$survey_num <- "Survey DT"

#Survey EEA2
EEA2_data$Q4_1A <- NA
EEA2_data$Q4_1A <- as.character(EEA2_data$Q4_1A)
EEA2_data$Q4_2A <- NA
EEA2_data$Q4_2A <- as.character(EEA2_data$Q4_2A)
EEA2_data$Q4_3A <- NA
EEA2_data$Q4_3A <- as.character(EEA2_data$Q4_3A)
EEA2_data$Q4_4A <- NA
EEA2_data$Q4_4A <- as.character(EEA2_data$Q4_4A)
EEA2_data$Q4_5A <- NA
EEA2_data$Q4_5A <- as.character(EEA2_data$Q4_5A)
EEA2_data$Q4_6A <- NA
EEA2_data$Q4_6A <- as.character(EEA2_data$Q4_6A)
EEA2_data$Q4_7A <- NA
EEA2_data$Q4_7A <- as.character(EEA2_data$Q4_7A)
EEA2_data$Q2_1.A <- NA
EEA2_data$Q2_1.A <- as.character(EEA2_data$Q2_1.A)
EEA2_data$Q2_2.A <- NA
EEA2_data$Q2_2.A <- as.character(EEA2_data$Q2_2.A)
EEA2_data$Q2_3.A <- NA
EEA2_data$Q2_3.A <- as.character(EEA2_data$Q2_3.A)
EEA2_data$Q2_4.A <- NA
EEA2_data$Q2_4.A <- as.character(EEA2_data$Q2_4.A)
EEA2_data$Q2_5.A <- NA
EEA2_data$Q2_5.A <- as.character(EEA2_data$Q2_5.A)
EEA2_data$Q2_6.A <- NA
EEA2_data$Q2_6.A <- as.character(EEA2_data$Q2_6.A)
EEA2_data$Q2_7.A <- NA
EEA2_data$Q2_7.A <- as.character(EEA2_data$Q2_7.A)
EEA2_data$Q2_8.A <- NA
EEA2_data$Q2_8.A <- as.character(EEA2_data$Q2_8.A)
EEA2_data$Q1.A <- NA
EEA2_data$Q1.A <- as.character(EEA2_data$Q1.A)
EEA2_data$Q5.A <- NA
EEA2_data$Q5.A <- as.character(EEA2_data$Q5.A)
EEA2_data$Q6_1.A <- NA
EEA2_data$Q6_1.A <- as.character(EEA2_data$Q6_1.A)
EEA2_data$Q9.A <- NA
EEA2_data$Q9.A <- as.character(EEA2_data$Q9.A)
EEA2_data$Q11A <- NA
EEA2_data$Q11A <- as.character(EEA2_data$Q11A)
EEA2_data$Q47A <- NA
EEA2_data$Q47A <- as.character(EEA2_data$Q47A)
EEA2_data$Q48A <- NA
EEA2_data$Q48A <- as.character(EEA2_data$Q48A)
EEA2_data$survey_num <- "Survey EEA2"

#Survey CESifo
CESifo_data$Q4_1A <- NA
CESifo_data$Q4_1A <- as.character(CESifo_data$Q4_1A)
CESifo_data$Q4_2A <- NA
CESifo_data$Q4_2A <- as.character(CESifo_data$Q4_2A)
CESifo_data$Q4_3A <- NA
CESifo_data$Q4_3A <- as.character(CESifo_data$Q4_3A)
CESifo_data$Q4_4A <- NA
CESifo_data$Q4_4A <- as.character(CESifo_data$Q4_4A)
CESifo_data$Q4_5A <- NA
CESifo_data$Q4_5A <- as.character(CESifo_data$Q4_5A)
CESifo_data$Q4_6A <- NA
CESifo_data$Q4_6A <- as.character(CESifo_data$Q4_6A)
CESifo_data$Q4_7A <- NA
CESifo_data$Q4_7A <- as.character(CESifo_data$Q4_7A)
CESifo_data$Q2_1.A <- NA
CESifo_data$Q2_1.A <- as.character(CESifo_data$Q2_1.A)
CESifo_data$Q2_2.A <- NA
CESifo_data$Q2_2.A <- as.character(CESifo_data$Q2_2.A)
CESifo_data$Q2_3.A <- NA
CESifo_data$Q2_3.A <- as.character(CESifo_data$Q2_3.A)
CESifo_data$Q2_4.A <- NA
CESifo_data$Q2_4.A <- as.character(CESifo_data$Q2_4.A)
CESifo_data$Q2_5.A <- NA
CESifo_data$Q2_5.A <- as.character(CESifo_data$Q2_5.A)
CESifo_data$Q2_6.A <- NA
CESifo_data$Q2_6.A <- as.character(CESifo_data$Q2_6.A)
CESifo_data$Q2_7.A <- NA
CESifo_data$Q2_7.A <- as.character(CESifo_data$Q2_7.A)
CESifo_data$Q2_8.A <- NA
CESifo_data$Q2_8.A <- as.character(CESifo_data$Q2_8.A)
CESifo_data$Q1.A <- NA
CESifo_data$Q1.A <- as.character(CESifo_data$Q1.A)
CESifo_data$Q5.A <- NA
CESifo_data$Q5.A <- as.character(CESifo_data$Q5.A)
CESifo_data$Q6_1.A <- NA
CESifo_data$Q6_1.A <- as.character(CESifo_data$Q6_1.A)
CESifo_data$Q9.A <- NA
CESifo_data$Q9.A <- as.character(CESifo_data$Q9.A)
CESifo_data$Q11A <- NA
CESifo_data$Q11A <- as.character(CESifo_data$Q11A)
CESifo_data$Q47A <- NA
CESifo_data$Q47A <- as.character(CESifo_data$Q47A)
CESifo_data$Q48A <- NA
CESifo_data$Q48A <- as.character(CESifo_data$Q48A)
CESifo_data$survey_num <- "Survey CESifo"

#Survey CEPR
CEPR_data$Q4_1A <- NA
CEPR_data$Q4_1A <- as.character(CEPR_data$Q4_1A)
CEPR_data$Q4_2A <- NA
CEPR_data$Q4_2A <- as.character(CEPR_data$Q4_2A)
CEPR_data$Q4_3A <- NA
CEPR_data$Q4_3A <- as.character(CEPR_data$Q4_3A)
CEPR_data$Q4_4A <- NA
CEPR_data$Q4_4A <- as.character(CEPR_data$Q4_4A)
CEPR_data$Q4_5A <- NA
CEPR_data$Q4_5A <- as.character(CEPR_data$Q4_5A)
CEPR_data$Q4_6A <- NA
CEPR_data$Q4_6A <- as.character(CEPR_data$Q4_6A)
CEPR_data$Q4_7A <- NA
CEPR_data$Q4_7A <- as.character(CEPR_data$Q4_7A)
CEPR_data$Q2_1.A <- NA
CEPR_data$Q2_1.A <- as.character(CEPR_data$Q2_1.A)
CEPR_data$Q2_2.A <- NA
CEPR_data$Q2_2.A <- as.character(CEPR_data$Q2_2.A)
CEPR_data$Q2_3.A <- NA
CEPR_data$Q2_3.A <- as.character(CEPR_data$Q2_3.A)
CEPR_data$Q2_4.A <- NA
CEPR_data$Q2_4.A <- as.character(CEPR_data$Q2_4.A)
CEPR_data$Q2_5.A <- NA
CEPR_data$Q2_5.A <- as.character(CEPR_data$Q2_5.A)
CEPR_data$Q2_6.A <- NA
CEPR_data$Q2_6.A <- as.character(CEPR_data$Q2_6.A)
CEPR_data$Q2_7.A <- NA
CEPR_data$Q2_7.A <- as.character(CEPR_data$Q2_7.A)
CEPR_data$Q2_8.A <- NA
CEPR_data$Q2_8.A <- as.character(CEPR_data$Q2_8.A)
CEPR_data$Q1.A <- NA
CEPR_data$Q1.A <- as.character(CEPR_data$Q1.A)
CEPR_data$Q5.A <- NA
CEPR_data$Q5.A <- as.character(CEPR_data$Q5.A)
CEPR_data$Q6_1.A <- NA
CEPR_data$Q6_1.A <- as.character(CEPR_data$Q6_1.A)
CEPR_data$Q9.A <- NA
CEPR_data$Q9.A <- as.character(CEPR_data$Q9.A)
CEPR_data$Q11A <- NA
CEPR_data$Q11A <- as.character(CEPR_data$Q11A)
CEPR_data$Q47A <- NA
CEPR_data$Q47A <- as.character(CEPR_data$Q47A)
CEPR_data$Q48A <- NA
CEPR_data$Q48A <- as.character(CEPR_data$Q48A)
CEPR_data$survey_num <- "Survey CEPR"

#Survey MM2
MM2_data$Q4_1A <- NA
MM2_data$Q4_1A <- as.character(MM2_data$Q4_1A)
MM2_data$Q4_2A <- NA
MM2_data$Q4_2A <- as.character(MM2_data$Q4_2A)
MM2_data$Q4_3A <- NA
MM2_data$Q4_3A <- as.character(MM2_data$Q4_3A)
MM2_data$Q4_4A <- NA
MM2_data$Q4_4A <- as.character(MM2_data$Q4_4A)
MM2_data$Q4_5A <- NA
MM2_data$Q4_5A <- as.character(MM2_data$Q4_5A)
MM2_data$Q4_6A <- NA
MM2_data$Q4_6A <- as.character(MM2_data$Q4_6A)
MM2_data$Q4_7A <- NA
MM2_data$Q4_7A <- as.character(MM2_data$Q4_7A)
MM2_data$Q2_1.A <- NA
MM2_data$Q2_1.A <- as.character(MM2_data$Q2_1.A)
MM2_data$Q2_2.A <- NA
MM2_data$Q2_2.A <- as.character(MM2_data$Q2_2.A)
MM2_data$Q2_3.A <- NA
MM2_data$Q2_3.A <- as.character(MM2_data$Q2_3.A)
MM2_data$Q2_4.A <- NA
MM2_data$Q2_4.A <- as.character(MM2_data$Q2_4.A)
MM2_data$Q2_5.A <- NA
MM2_data$Q2_5.A <- as.character(MM2_data$Q2_5.A)
MM2_data$Q2_6.A <- NA
MM2_data$Q2_6.A <- as.character(MM2_data$Q2_6.A)
MM2_data$Q2_7.A <- NA
MM2_data$Q2_7.A <- as.character(MM2_data$Q2_7.A)
MM2_data$Q2_8.A <- NA
MM2_data$Q2_8.A <- as.character(MM2_data$Q2_8.A)
MM2_data$Q1.A <- NA
MM2_data$Q1.A <- as.character(MM2_data$Q1.A)
MM2_data$Q5.A <- NA
MM2_data$Q5.A <- as.character(MM2_data$Q5.A)
MM2_data$Q6_1.A <- NA
MM2_data$Q6_1.A <- as.character(MM2_data$Q6_1.A)
MM2_data$Q9.A <- NA
MM2_data$Q9.A <- as.character(MM2_data$Q9.A)
MM2_data$Q11A <- NA
MM2_data$Q11A <- as.character(MM2_data$Q11A)
MM2_data$Q47A <- NA
MM2_data$Q47A <- as.character(MM2_data$Q47A)
MM2_data$Q48A <- NA
MM2_data$Q48A <- as.character(MM2_data$Q48A)
MM2_data$survey_num <- "Survey MM2"

#Combine datasets
complete_data <- full_join(pilot_survey, ESA_data)
complete_data <- rbind(complete_data, EEA1_data)
complete_data <- rbind(complete_data, MM1_data)
complete_data <- rbind(complete_data, DT_data)
complete_data <- rbind(complete_data, EEA2_data)
complete_data <- rbind(complete_data, CESifo_data)
complete_data <- rbind(complete_data, CEPR_data)
complete_data <- rbind(complete_data, MM2_data)


##Rename Variables for clarity
complete_data <- complete_data %>% dplyr::rename(Consent=Q1, num_pap_sub=Q1.1, perc_ref_rep_qual_v_low=Q2_1, perc_ref_rep_qual_f_low=Q2_2, perc_ref_rep_qual_avg=Q2_3, perc_ref_rep_qual_f_high=Q2_4, perc_ref_rep_qual_v_high=Q2_5, low_qual_char=Q3, low_qual_char_other=Q3_8_TEXT, perct_num_rep_rec_0=Q4_1A, perct_num_rep_rec_1=Q4_2A, perct_num_rep_rec_2=Q4_3A, perct_num_rep_rec_3=Q4_4A, perct_num_rep_rec_4=Q4_5A, perct_num_rep_rec_5=Q4_6A, perct_num_rep_rec_over5=Q4_7A)  
complete_data <- complete_data %>% dplyr::rename(rank_ref_rep_obj_1_help_editor=Q5_1, rank_ref_rep_obj_2_gen_comments=Q5_2, rank_ref_rep_obj_3_precise_suggest=Q5_3, rank_ref_rep_obj_4_detailed_feedback=Q5_4, rank_ref_rep_obj_rand_ord=Q5_DO, rank_peer_rev_proc_1_useful_feedback=Q6_1, rank_peer_rev_proc_2_timely_decision=Q6_2, rank_peer_rev_proc_3_reasonable_decision=Q6_3, rank_peer_rev_proc_rand_ord=Q6_DO)
complete_data <- complete_data %>% dplyr::rename(peer_rev_prop_1_guidelines=Q1_1,peer_rev_prop_2_doc_train=Q1_2, peer_rev_prop_3_hist_avail=Q1_3, peer_rev_prop_4_remov_sen_anon=Q1_4, peer_rev_prop_5_remov_assoc_edit_anon=Q1_5, peer_rev_prop_6_grading_rep=Q1_6, peer_rev_prop_7_ref_track_platform=Q1_7, peer_rev_prop_8_all_rep_avail=Q1_8)
complete_data <- complete_data %>% dplyr::rename(rank_useful_comm_1_clar_contr=Q2_1.A, rank_useful_comm_2_assum_persp=Q2_2.A, rank_useful_comm_3_pres_res=Q2_3.A, rank_useful_comm_4_short_restruc=Q2_4.A, rank_useful_comm_5_improv_analysis=Q2_5.A, rank_useful_comm_6_poss_exten=Q2_6.A, rank_useful_comm_7_robust=Q2_7.A, rank_useful_comm_8_miss_ref=Q2_8.A, rank_useful_comm_rand=Q2_DO)
complete_data <- complete_data %>% dplyr::rename(ref_report_template=Q3.1, Open_peer_rev_pol=Q4, Open_peer_rev_pol_sen=Q5, peer_rev_hist_avail=Q6, ref_track_platform=Q7, ref_reward=Q8, how_ref_reward=Q9, how_ref_reward_other=Q9_4_TEXT, suf_num_reports=Q1.A, time_length_rev_reports=Q2.1, desk_rej=Q3.2, AER_Insights_model=Q4.1, author_resp_ref=Q5.1, other_peer_rev_props=Q6.1)
complete_data <- complete_data %>% dplyr::rename(ref_repor_per_year=Q1.2, perc_ref_rep_journals_1_top_5=Q2_1.1, perc_ref_rep_journals_2_top_field=Q2_2.1, perc_ref_rep_journals_3_other_econ=Q2_3.1, perc_ref_rep_journals_4_other_discipline=Q2_4.1, have_been_editor=Q3.3, time_spent_on_report=Q4.2, how_detailed_reports=Q5.A, perc_time_reports_unfamiliar_topics=Q6_1.A)
complete_data <- complete_data %>% dplyr::rename(perc_time_late=Q7_1, avg_delay_time=Q8.1, feeling_amt_time_ref=Q9.A, rej_ref_req=Q10, rej_ref_req_num_times=Q11A, rej_ref_req_reasons=Q12,  rej_ref_req_reasons_other=Q12_7_TEXT, rej_ref_req_temp_num_times=Q11.1, rej_ref_req_temp_reasons=Q12.1, rej_ref_req_temp_reason_other=Q12_7_TEXT.1)
complete_data <- complete_data %>% dplyr::rename(ref_for_friends=Q13, rank_ref_benefits_1_attent_read=Q45_1, rank_ref_benefits_2_know_edit=Q45_2, rank_ref_benefits_3_better_write=Q45_3, rank_ref_benefits_4_learn_from_others=Q45_4, rank_ref_benefits_5_ensure_right_pub=Q45_5, rank_ref_benefits_rand=Q45_DO, ref_impor=Q46, suff_recog_ref=Q47A, better_recog_ref=Q48A)
complete_data <- complete_data %>% dplyr::rename(rank_improv_ref_exp_1_edit_share_dec=Q49_1, rank_improv_ref_exp_2_edit_guide=Q49_2, rank_improv_ref_exp_3_get_only_related_papers=Q49_3, rank_improv_ref_exp_4_limit_on_req=Q49_4, rank_improv_ref_exp_rand=Q49_DO, sugg_improv_ref_exp=Q55)
complete_data <- complete_data %>% dplyr::rename(num_papers_pub=Q1.3, research_areas=Q56, research_areas_other=Q56_20_TEXT, gender=Q3.4, age=Q4.3, position=Q5.2, location=Q58, section_rand=FL_6_DO)
complete_data <- complete_data %>% dplyr::rename(useful_comm_select=Q2, reas_num_reports_per_yr=Q9.1, rej_ref_req_num_times_with_0=Q11, comm_about_survey=Q58.1)
complete_data <- complete_data %>% dplyr::rename(duration=`Duration (in seconds)`)
complete_data <- complete_data %>% dplyr::rename(fav_double_blind=Q59, fav_disq_rev=Q60)

#Add labels to variables for clarity
complete_data = apply_labels(complete_data,
                             Progress = "Percentage of survey completed",
                      duration = "Time spent on survey (in seconds)",
                      Finished = "Binary for if the survey was entirely completed",
                      Consent = "Affirmation of consent that survey data can be used for research purposes",
                      num_pap_sub = "Number of papers submitted to econ journals over that last two years (with submissions of the same paper to different journals included separately)",
                      perc_ref_rep_qual_v_low = "Percentage of very low quality referee reports received over the last two years",
                      perc_ref_rep_qual_f_low = "Percentage of fairly low quality referee reports received over the last two years",
                      perc_ref_rep_qual_avg = "Percentage of average quality referee reports received over the last two years",
                      perc_ref_rep_qual_f_high = "Percentage of fairly high quality referee reports received over the last two years",
                      perc_ref_rep_qual_v_high = "Percentage of very high quality referee reports received over the last two years",
                      low_qual_char = "Characteristics of low quality reports",
                      low_qual_char_other = "Text input for other low quality characteristics",
                      perct_num_rep_rec_0 = "Percentage of time no reports were received over the past two years (desk rejection)",
                      perct_num_rep_rec_1 = "Percentage of time 1 report was received over the past two years",
                      perct_num_rep_rec_2 = "Percentage of time 2 reports were received over the past two years",
                      perct_num_rep_rec_3 = "Percentage of time 3 reports were received over the past two years",
                      perct_num_rep_rec_4 = "Percentage of time 4 reports were received over the past two years",
                      perct_num_rep_rec_5 = "Percentage of time 5 reports were received over the past two years",
                      perct_num_rep_rec_over5 = "Percentage of time more than  5 reports were received over the past two years",
                      rank_ref_rep_obj_1_help_editor = "Importance of referee report objectives (rank) - help editor reach an informed decision",
                      rank_ref_rep_obj_2_gen_comments = "Importance of referee report objectives (rank) - give general comments",
                      rank_ref_rep_obj_3_precise_suggest = "Importance of referee report objectives (rank) - make precise suggestions",
                      rank_ref_rep_obj_4_detailed_feedback = "Importance of referee report objectives (rank) - provide detailed feedback",
                      rank_ref_rep_obj_rand_ord = "Random order in the survey of the previous four statements about importance of referee report objectives (rank)",
                      rank_peer_rev_proc_1_useful_feedback = "Expectation of peer review process as an author (rank) - getting useful feedback",
                      rank_peer_rev_proc_2_timely_decision = "Expectation of peer review process as an author (rank) - timely decision",
                      rank_peer_rev_proc_3_reasonable_decision = "Expectation of peer review process as an author (rank) - getting a reasonable and well-substantiated decision",
                      rank_peer_rev_proc_rand_ord = "Random order in the survey of the previous three statements about expectation of peer review process as an author (rank)",
                      peer_rev_prop_1_guidelines = "Proposal: Provide guidelines for writing reports (1-5)",
                      peer_rev_prop_2_doc_train = "Proposal: Provide doctoral training on how to write reports (1-5)",
                      peer_rev_prop_3_hist_avail = "Proposal: Making history of reviews and responses publicly available (1-5)",
                      peer_rev_prop_4_remov_sen_anon = "Proposal: Remove anonymity of senior referees (1-5)",
                      peer_rev_prop_5_remov_assoc_edit_anon = "Proposal: Remove anonymity of associate editors (1-5)",
                      peer_rev_prop_6_grading_rep = "Proposal: Grading reports and rewarding referees for high-quality reports (1-5)",
                      peer_rev_prop_7_ref_track_platform = "Proposal: Encourage use of platforms that centrally track referee activity (1-5)",
                      peer_rev_prop_8_all_rep_avail = "Proposal: Making all reports available to all reviewers (1-5)",
                      rank_useful_comm_1_clar_contr = "Most useful comments (rank) - comments that clarify contribution of the paper",
                      rank_useful_comm_2_assum_persp = "Most useful comments (rank) - comments that put assumptions in perspective",
                      rank_useful_comm_3_pres_res = "Most useful comments (rank) - comments about the presentation of results",
                      rank_useful_comm_4_short_restruc = "Most useful comments (rank) - comments about shortening/restructuring the paper",
                      rank_useful_comm_5_improv_analysis = "Most useful comments (rank) - Suggestions to improve the existing analysis",
                      rank_useful_comm_6_poss_exten = "Most useful comments (rank) - Suggestions about possible extensions",
                      rank_useful_comm_7_robust = "Most useful comments (rank) - Robustness Checks",
                      rank_useful_comm_8_miss_ref = "Most useful comments (rank) - Comments about missing previous work and references",
                      rank_useful_comm_rand = "Most useful comments (rank) - random order",
                      ref_report_template = "Do you think journals or associations should provide a template for referee reports?",
                      Open_peer_rev_pol = "Favorability of open peer review process (1-5)",
                      Open_peer_rev_pol_sen = "Favorability of open peer review process only for senior reviewers (1-5)",
                      peer_rev_hist_avail = "Favorability of making (anonymized) history of reports/responses publicly available (1-5)",
                      ref_track_platform = "Favorability of more widespread use of Publons or a similar platform (1-5)",
                      ref_reward = "Do you think that referees would do a better job if they were better rewarded for their work?",
                      how_ref_reward = "How should referees be rewarded?",
                      how_ref_reward_other = "How should referees be rewarded? - Other Text",
                      suf_num_reports = "What do you think is a sufficient number of reports for a paper?",
                      time_length_rev_reports = "What do you think is an appropriate time length to give to reviewers to submit their reports (in weeks)?",
                      desk_rej = "How do you feel about the policy of having desk rejections? (1-5)",
                      AER_Insights_model = "Favorability towards AER: Insights model (1-5)",
                      author_resp_ref = "Favorability towards authors being allowed to submit a single response (1-5)",
                      other_peer_rev_props = "Additional proposals to improve the peer review process (write-in)",
                      ref_repor_per_year = "On average, how many referee reports do you write per year?",
                      perc_ref_rep_journals_1_top_5 = "What percentage of the time do you write referee reports for top 5 journals?",
                      perc_ref_rep_journals_2_top_field = "What percentage of the time do you write referee reports for top field journals?",
                      perc_ref_rep_journals_3_other_econ = "What percentage of the time do you write referee reports for other econ journals?",
                      perc_ref_rep_journals_4_other_discipline = "What percentage of the time do you write referee reports for journals in other disciplines?",
                      have_been_editor = "Have you occupied or are you currently occupying an editorial position?",
                      time_spent_on_report = "Usually, how much time do you spend on a referee report, including reading the paper and writing the report?",
                      how_detailed_reports = "Usually, how detailed are your reports?",
                      perc_time_reports_unfamiliar_topics = "Percentage of time assigned papers on topics or methods they have little expertise on",
                      perc_time_late = "Percentage of time submitting referee reports late",
                      avg_delay_time = "Average amount of time for delay of submitting referee reports",
                      feeling_amt_time_ref = "Do you consider that your amount of refereeing is: (far too low - far too high)",
                      rej_ref_req = "Did you reject a request to referee over these past two years?",
                      rej_ref_req_num_times = "How many times did you reject a request to referee? (without 0)",
                      rej_ref_req_reasons = "Main reason for rejecting referee requests",
                      rej_ref_req_reasons_other = "Main reason for rejecting referee requests - other text",
                      rej_ref_req_temp_num_times = "Number of times feeling tempted to reject a referee request",
                      rej_ref_req_temp_reasons = "Reasons for being tempted to reject a referee request",
                      rej_ref_req_temp_reason_other = "Reasons for being tempted to reject a referee request - other text",
                      ref_for_friends = "How do you feel about people refereeing papers by co-authors or friends?",
                      rank_ref_benefits_1_attent_read = "Biggest benefits of being a referee (rank) - Attentively read papers they would never read otherwise",
                      rank_ref_benefits_2_know_edit = "Biggest benefits of being a referee (rank) - Get to know editors and make themselves known to them",
                      rank_ref_benefits_3_better_write = "Biggest benefits of being a referee (rank) - make themselves a better writer",
                      rank_ref_benefits_4_learn_from_others = "Biggest benefits of being a referee (rank) - learn from opinions of other referees and editors",
                      rank_ref_benefits_5_ensure_right_pub = "Biggest benefits of being a referee (rank) - Ensure the right papers are published and rejected",
                      rank_ref_benefits_rand = "Biggest benefits of being a referee (rank) - random order",
                      ref_impor = "Importance of referee role (1-5)",
                      suff_recog_ref = "Sufficient recognition received for refereeing?",
                      better_recog_ref = "How could work as referee be better recognized (write-in)",
                      rank_improv_ref_exp_1_edit_share_dec = "Improvement of referee experience (rank) - editors systematically share their decision and other reports",
                      rank_improv_ref_exp_2_edit_guide = "Improvement of referee experience (rank) -The editors give clear guidance of what they would like to learn from my report",
                      rank_improv_ref_exp_3_get_only_related_papers = "Improvement of referee experience (rank) - Assigned only papers related to research",
                      rank_improv_ref_exp_4_limit_on_req = "Improvement of referee experience (rank) - global annual limit on referee requests",
                      rank_improv_ref_exp_rand = "Improvement of referee experience (rank) - random order",
                      sugg_improv_ref_exp = "Additional suggestions to improve peer review process (write-in)",
                      num_papers_pub = "Number of papers published",
                      research_areas = "Key areas of research",
                      research_areas_other = "Key areas of research - other text",
                      gender = "Gender",
                      age = "Age",
                      position = "Job Position",
                      location = "Location of Job",
                      section_rand = "Randomization of main sections",
                      useful_comm_select = "Most useful comments (Select)",
                      reas_num_reports_per_yr = "What do you think is a reasonable number of reports to be assigned per year?",
                      rej_ref_req_num_times_with_0 = "How many times did you reject a request to referee? (with 0)",
                      comm_about_survey = "Comments about the survey itself",
                      survey_num = "Survey taken for this response",
                      fav_double_blind = "Favorability towards using a double-blind review process (1-5)",
                      fav_disq_rev = "Favorability towards allowing authors to suggest certain reviewers who should be disqualified from reviewing their work (2-5)"
                      )


#### Statistics for the appendix
## Number of at least partially completed surveys
# "4" (4% completion) is the amount of the survey where the respondent only consented, but did not answer any questions
complete_data$Progress <- as.numeric(complete_data$Progress)
nrow(complete_data[complete_data$Progress>4,])

## Number of fully completed surveys
nrow(complete_data[complete_data$Finished=="True",])

## Median time to complete survey for fully completed surveys
median(as.numeric(complete_data$duration[complete_data$Finished=="True"])/60)

#Reorder variables so they match survey order
complete_data <- complete_data[,c(107,1:36,103,37:60,108:109,61:71,104,72:73,105,74:101,106,102)]

#Export data
write.xlsx(complete_data, paste0(outpath,"all_survey_data.xlsx"))




