***********************************************************************************************************************
***********************************************************************************************************************
README - "Open Science, Closed Peer Review?"
***********************************************************************************************************************
***********************************************************************************************************************

This is the readme file for the replication package of the paper entitled "Open Science, Closed Peer Review?" by Gary Charness, Anna Dreber, Daniel Evans, Adam Gill, and Séverine Toussaert. The replication package includes this readme file and five folders containing the data, code, and generated figures.  


******************************************************
Information to run replication
******************************************************

In order to run the replication, the "raw path" string at the top of each of the four R-script files needs to be replaced with the location of this replication package folder. Then each R-script needs to be run individually in the order denoted by the numbering (A.1 then A.2 then A.3 then A.4). 

The entire replication of the main results, figures, and tables related to our survey as well as all results, figures, and tables in the supplemental appendix that are related to our survey can be generated using this replication package. The only statistics and tables that cannot be generated are those related to comparison statistics from other papers or descriptives on journal policies and journal statistics that were generated and obtained externally. Some of the statistics and table results found in the paper are printed in the console from running the code.  

R packages used: rio, tidyverse, ggplot2, stargazer, openxlsx, expss, plyr, dplyr, grid, ggcorrplot, jtools, psych, poLCA, reshape2, stringr, ggtext, tm, wordcloud, SnowballC


******************************************************
Included files
******************************************************

******************
*** Survey files
******************

The original survey was run using Qualtrics. This replication file includes the .pdf and .qsf (Qualtrics file) of an example of the original survey that respondents would have faced. The actual survey may have differed slightly as the ordering of the survey parts I and II were randomized across respondents and there were small differences in the survey questions across waves. More details about this can be found in the appendix of the paper as well as in a report we wrote that discusses the survey process and a broader set of descriptives from the survey in more detail (Charness, G., A. Dreber, D. Evans, A. Gill, and S. Toussaert (2022). Improving Peer Review in Economics: Stocktaking
and Proposals). These files can be found in the folder "~/Replication Package/Original Questionaire/".

	[1] survey_file.qsf 
		Qualtrics file of the original survey

	[2] survey_pdf.pdf
		PDF version of the original survey that preserves the main structure and look of the survey that the respondents would have faced


******************
*** Data files
******************

** Raw survey responses - The files for the raw survey responses for the main survey can all be found in the folder "~/Replication Package/Peer Review Survey Reponses/" and are listed here. There are nine different files which each correspond to a different wave or target group. They contain mostly the same questions with a few deviations between the pilot stage and the later surveys, and a few additional questions added to the later round. For this paper, we only use a subset of the survey responses (some general questions and then policy questions related to transparency policies) but we include the responses to the full survey here. More details can be found in the paper as well as in the associated report. 

	[1] CEPR survey - January 8, 2021.csv
	[2] CESifo survey - January 8, 2021.csv
	[3] DT Survey - January 8, 2021.csv
	[4] EEA Survey 1 - January 3, 2021.csv
	[5] EEA Survey 2 - January 8, 2021.csv
	[6] ESA - January 3, 2021.csv
	[7] Mail merge 1 - January 3, 2021.csv
	[8] Mail merge 2 - February 20, 2021.csv
	[9] Pilot Survey - January 3, 2021.csv

** Follow-up survey responses - We also ran a follow-up survey on a small sample of respondents for more clarity on some responses and additional information. We do not discuss the results of this survey in the main part of the paper as it has little relevance to the transparency responses, but we include a small discussion of it in the supplemental appendix and include the data here for completeness. These responses can be found in the folder "~/Replication Package/Peer Review Survey Reponses/Followup Survey/".

	[1] follow_up_survey.csv 
		Raw responses for the follow-up survey

	[2] Peer Review Report - Follow-up survey.pdf
		A pdf of the original survey questions asked to respondents

** Cleaned data - There is also a file for the cleaned data that is generated from the first R-script ("A.1 - Survey data formatting.R") which combines all the original survey responses, recodes and cleans some of the variables, and generates new, relevant variables from the responses. This is the main dataset used in the analysis of the paper. It can be found in the folder "~/Replication Package/Cleaned Data/".

	[1] all_survey_data.xlsx

** Comments data - For some of our analysis, we also explore the open text comments that people left. We have extracted these from the main responses and manually organized them by type and relevance. The documents related to the extracted comments and comment analysis can be found in folder "~/Replication Package/Data about comments/". 

	[1] comments about improving peer review.xlsx
	[2] comments about incentives.xlsx
	[2] comments_combined.xlsx
	[2] intreactive review comments 2.xlsx
	[2] intreactive review comments.xlsx


******************
*** Code files
******************

All coding is done in R (Version 4.4.2) and is spread across four R-scripts. They are all found in the folder "~/Replication Package/R scripts/".

	[1] "A.1 - Survey data formatting.R" 
		This file contains the data cleaning code that combines the responses to all the different survey versions, constructs new variables from the responses, and cleans the data. It outputs the main data file as "~/Replication Package/Cleaned Data/all_survey_data.xlsx".

	[2] "A.2 - Analysis and figures.R" 
		This file does all of the analysis from the main part of the paper and some of the analysis in the supplemental appendix. It also generates all of the figures from the main part of the paper and some of the appendix tables and figures results. All of the figures generated are saved in the folder "~/Replication Package/Figures/".
	
	[3] "A.3 - Additional Appendix tables.R"
		This file includes some of the statistics and table responses from the supplemental appendix, primarily the statistics and tables related to the entire original sample of respondents (not the behavioral/experimental subset that is the primary sample of the main analysis).

	[4] "A.4 - Follow up survey analysis.R"
		This file contains the cleaning and descriptive statistics about the follow-up survey 



******************************************************
Variable names
******************************************************

Here we detail the names of the variables found in the data. Each row in the data represents the answers for one of our respondents. Combined, we had a total of 1,596 responses of which 1,459 were fully completed and 802 were for the subset of behavioral/experimental economists that we focus on. The main survey contains metadata variables as well as responses to the questions totaling 109 variables. Below is a list of all of the variables found in the cleaned data output. 

                      Progress = "Percentage of survey completed",
                      duration = "Time spent on survey (in seconds)",
                      Finished = "Binary for if the survey was entirely completed",
                      Consent = "Affirmation of consent that survey data can be used for research purposes",
                      num_pap_sub = "Number of papers submitted to econ journals over that last two years (with submissions of the same paper to different journals included separately)",
                      perc_ref_rep_qual_v_low = "Percentage of very low quality referee reports received over the last two years",
                      perc_ref_rep_qual_f_low = "Percentage of fairly low quality referee reports received over the last two years",
                      perc_ref_rep_qual_avg = "Percentage of average quality referee reports received over the last two years",
                      perc_ref_rep_qual_f_high = "Percentage of fairly high quality referee reports received over the last two years",
                      perc_ref_rep_qual_v_high = "Percentage of very high quality referee reports received over the last two years",
                      low_qual_char = "Characteristics of low quality reports",
                      low_qual_char_other = "Text input for other low quality characteristics",
                      perct_num_rep_rec_0 = "Percentage of time no reports were received over the past two years (desk rejection)",
                      perct_num_rep_rec_1 = "Percentage of time 1 report was received over the past two years",
                      perct_num_rep_rec_2 = "Percentage of time 2 reports were received over the past two years",
                      perct_num_rep_rec_3 = "Percentage of time 3 reports were received over the past two years",
                      perct_num_rep_rec_4 = "Percentage of time 4 reports were received over the past two years",
                      perct_num_rep_rec_5 = "Percentage of time 5 reports were received over the past two years",
                      perct_num_rep_rec_over5 = "Percentage of time more than  5 reports were received over the past two years",
                      rank_ref_rep_obj_1_help_editor = "Importance of referee report objectives (rank) - help editor reach an informed decision",
                      rank_ref_rep_obj_2_gen_comments = "Importance of referee report objectives (rank) - give general comments",
                      rank_ref_rep_obj_3_precise_suggest = "Importance of referee report objectives (rank) - make precise suggestions",
                      rank_ref_rep_obj_4_detailed_feedback = "Importance of referee report objectives (rank) - provide detailed feedback",
                      rank_ref_rep_obj_rand_ord = "Random order in the survey of the previous four statements about importance of referee report objectives (rank)",
                      rank_peer_rev_proc_1_useful_feedback = "Expectation of peer review process as an author (rank) - getting useful feedback",
                      rank_peer_rev_proc_2_timely_decision = "Expectation of peer review process as an author (rank) - timely decision",
                      rank_peer_rev_proc_3_reasonable_decision = "Expectation of peer review process as an author (rank) - getting a reasonable and well-substantiated decision",
                      rank_peer_rev_proc_rand_ord = "Random order in the survey of the previous three statements about expectation of peer review process as an author (rank)",
                      peer_rev_prop_1_guidelines = "Proposal: Provide guidelines for writing reports (1-5)",
                      peer_rev_prop_2_doc_train = "Proposal: Provide doctoral training on how to write reports (1-5)",
                      peer_rev_prop_3_hist_avail = "Proposal: Making history of reviews and responses publicly available (1-5)",
                      peer_rev_prop_4_remov_sen_anon = "Proposal: Remove anonymity of senior referees (1-5)",
                      peer_rev_prop_5_remov_assoc_edit_anon = "Proposal: Remove anonymity of associate editors (1-5)",
                      peer_rev_prop_6_grading_rep = "Proposal: Grading reports and rewarding referees for high-quality reports (1-5)",
                      peer_rev_prop_7_ref_track_platform = "Proposal: Encourage use of platforms that centrally track referee activity (1-5)",
                      peer_rev_prop_8_all_rep_avail = "Proposal: Making all reports available to all reviewers (1-5)",
                      rank_useful_comm_1_clar_contr = "Most useful comments (rank) - comments that clarify contribution of the paper",
                      rank_useful_comm_2_assum_persp = "Most useful comments (rank) - comments that put assumptions in perspective",
                      rank_useful_comm_3_pres_res = "Most useful comments (rank) - comments about the presentation of results",
                      rank_useful_comm_4_short_restruc = "Most useful comments (rank) - comments about shortening/restructuring the paper",
                      rank_useful_comm_5_improv_analysis = "Most useful comments (rank) - Suggestions to improve the existing analysis",
                      rank_useful_comm_6_poss_exten = "Most useful comments (rank) - Suggestions about possible extensions",
                      rank_useful_comm_7_robust = "Most useful comments (rank) - Robustness Checks",
                      rank_useful_comm_8_miss_ref = "Most useful comments (rank) - Comments about missing previous work and references",
                      rank_useful_comm_rand = "Most useful comments (rank) - random order",
                      ref_report_template = "Do you think journals or associations should provide a template for referee reports?",
                      Open_peer_rev_pol = "Favorability of open peer review process (1-5)",
                      Open_peer_rev_pol_sen = "Favorability of open peer review process only for senior reviewers (1-5)",
                      peer_rev_hist_avail = "Favorability of making (anonymized) history of reports/responses publicly available (1-5)",
                      ref_track_platform = "Favorability of more widespread use of Publons or a similar platform (1-5)",
                      ref_reward = "Do you think that referees would do a better job if they were better rewarded for their work?",
                      how_ref_reward = "How should referees be rewarded?",
                      how_ref_reward_other = "How should referees be rewarded? - Other Text",
                      suf_num_reports = "What do you think is a sufficient number of reports for a paper?",
                      time_length_rev_reports = "What do you think is an appropriate time length to give to reviewers to submit their reports (in weeks)?",
                      desk_rej = "How do you feel about the policy of having desk rejections? (1-5)",
                      AER_Insights_model = "Favorability towards AER: Insights model (1-5)",
                      author_resp_ref = "Favorability towards authors being allowed to submit a single response (1-5)",
                      other_peer_rev_props = "Additional proposals to improve the peer review process (write-in)",
                      ref_repor_per_year = "On average, how many referee reports do you write per year?",
                      perc_ref_rep_journals_1_top_5 = "What percentage of the time do you write referee reports for top 5 journals?",
                      perc_ref_rep_journals_2_top_field = "What percentage of the time do you write referee reports for top field journals?",
                      perc_ref_rep_journals_3_other_econ = "What percentage of the time do you write referee reports for other econ journals?",
                      perc_ref_rep_journals_4_other_discipline = "What percentage of the time do you write referee reports for journals in other disciplines?",
                      have_been_editor = "Have you occupied or are you currently occupying an editorial position?",
                      time_spent_on_report = "Usually, how much time do you spend on a referee report, including reading the paper and writing the report?",
                      how_detailed_reports = "Usually, how detailed are your reports?",
                      perc_time_reports_unfamiliar_topics = "Percentage of time assigned papers on topics or methods they have little expertise on",
                      perc_time_late = "Percentage of time submitting referee reports late",
                      avg_delay_time = "Average amount of time for delay of submitting referee reports",
                      feeling_amt_time_ref = "Do you consider that your amount of refereeing is: (far too low - far too high)",
                      rej_ref_req = "Did you reject a request to referee over these past two years?",
                      rej_ref_req_num_times = "How many times did you reject a request to referee? (without 0)",
                      rej_ref_req_reasons = "Main reason for rejecting referee requests",
                      rej_ref_req_reasons_other = "Main reason for rejecting referee requests - other text",
                      rej_ref_req_temp_num_times = "Number of times feeling tempted to reject a referee request",
                      rej_ref_req_temp_reasons = "Reasons for being tempted to reject a referee request",
                      rej_ref_req_temp_reason_other = "Reasons for being tempted to reject a referee request - other text",
                      ref_for_friends = "How do you feel about people refereeing papers by co-authors or friends?",
                      rank_ref_benefits_1_attent_read = "Biggest benefits of being a referee (rank) - Attentively read papers they would never read otherwise",
                      rank_ref_benefits_2_know_edit = "Biggest benefits of being a referee (rank) - Get to know editors and make themselves known to them",
                      rank_ref_benefits_3_better_write = "Biggest benefits of being a referee (rank) - make themselves a better writer",
                      rank_ref_benefits_4_learn_from_others = "Biggest benefits of being a referee (rank) - learn from opinions of other referees and editors",
                      rank_ref_benefits_5_ensure_right_pub = "Biggest benefits of being a referee (rank) - Ensure the right papers are published and rejected",
                      rank_ref_benefits_rand = "Biggest benefits of being a referee (rank) - random order",
                      ref_impor = "Importance of referee role (1-5)",
                      suff_recog_ref = "Sufficient recognition received for refereeing?",
                      better_recog_ref = "How could work as referee be better recognized (write-in)",
                      rank_improv_ref_exp_1_edit_share_dec = "Improvement of referee experience (rank) - editors systematically share their decision and other reports",
                      rank_improv_ref_exp_2_edit_guide = "Improvement of referee experience (rank) -The editors give clear guidance of what they would like to learn from my report",
                      rank_improv_ref_exp_3_get_only_related_papers = "Improvement of referee experience (rank) - Assigned only papers related to research",
                      rank_improv_ref_exp_4_limit_on_req = "Improvement of referee experience (rank) - global annual limit on referee requests",
                      rank_improv_ref_exp_rand = "Improvement of referee experience (rank) - random order",
                      sugg_improv_ref_exp = "Additional suggestions to improve peer review process (write-in)",
                      num_papers_pub = "Number of papers published",
                      research_areas = "Key areas of research",
                      research_areas_other = "Key areas of research - other text",
                      gender = "Gender",
                      age = "Age",
                      position = "Job Position",
                      location = "Location of Job",
                      section_rand = "Randomization of main sections",
                      useful_comm_select = "Most useful comments (Select)",
                      reas_num_reports_per_yr = "What do you think is a reasonable number of reports to be assigned per year?",
                      rej_ref_req_num_times_with_0 = "How many times did you reject a request to referee? (with 0)",
                      comm_about_survey = "Comments about the survey itself",
                      survey_num = "Survey taken for this response",
                      fav_double_blind = "Favorability towards using a double-blind review process (1-5)",
                      fav_disq_rev = "Favorability towards allowing authors to suggest certain reviewers who should be disqualified from reviewing their work (2-5)"


******************************************************
Contact
******************************************************

For further questions, please contact: anna.dreber@hhs.se
	